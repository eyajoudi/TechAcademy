import unittest
from agents.fraud_detection import FraudDetectionAgent
from agents.advanced_customer_ai import AdvancedCustomerAI
from agents.financial_intelligence import FinancialIntelligenceAgent

class V8ModuleTests(unittest.TestCase):
    def test_fraud_score_is_bounded_and_explainable(self):
        result=FraudDetectionAgent().assess({"amount":1500,"hour":2,"transactions_10m":7,
            "failed_attempts_24h":4,"new_device":True,"geo_distance_km":250,"merchant_mismatch":True})
        self.assertGreaterEqual(result["risk_score"],0)
        self.assertLessEqual(result["risk_score"],100)
        self.assertTrue(result["signals"])
        self.assertEqual(result["model"],"RandomForestClassifier")

    def test_advanced_ai_returns_class_and_topics(self):
        result=AdvancedCustomerAI().analyze("La formation est trop chère et je veux un programme sécurisé")
        self.assertIn(result["label"],["positive","negative","neutral","mixed"])
        self.assertIn("course_content",result["topics"])
        self.assertIn("pricing",result["topics"])

    def test_financial_intelligence_calculates_metrics(self):
        rows=[{"payment_status":"succeeded","amount":100,"product_name":"Wallet"},
              {"payment_status":"failed","amount":50,"product_name":"Wallet"},
              {"payment_status":"pending_security","amount":80,"product_name":"Billing"}]
        result=FinancialIntelligenceAgent().run(rows)
        self.assertEqual(result["simulated_revenue"],100)
        self.assertEqual(result["successful_transactions"],1)
        self.assertEqual(result["failed_transactions"],1)
        self.assertEqual(result["pending_transactions"],1)

if __name__=="__main__": unittest.main()
