import os
import tempfile
import unittest

class AllowAdapter:
    def review(self, context):
        return {"decision":"allow","risk_level":"low","reasons":["Local test allow"],
                "requires_human_approval":True}

class ReviewAdapter:
    def review(self, context):
        return {"decision":"review","risk_level":"medium","reasons":["Manual security review"],
                "requires_human_approval":True}

class V13OwnerPaymentWorkflowTests(unittest.TestCase):
    def _app(self, tmp, adapter):
        from services.database import connect
        from orchestrator import TrainingCenterOrchestrator
        os.chdir(tmp)
        os.makedirs("data", exist_ok=True)
        self.conn = connect()
        return TrainingCenterOrchestrator(self.conn, security_adapter=adapter)

    def test_owner_approve_then_learner_confirms_simulated_payment(self):
        with tempfile.TemporaryDirectory() as tmp:
            old=os.getcwd()
            try:
                app=self._app(tmp, AllowAdapter())
                ctx=app.run("Demo Learner","ai_fundamentals","Je veux m'inscrire.","Intéressé","text",True)
                approved=app.approve_payment_request(ctx.payment_request_id,"Owner")
                self.assertEqual(approved["status"],"approved_pending_customer_payment")
                paid=app.complete_customer_payment(ctx.payment_request_id,True)
                self.assertEqual(paid["status"],"succeeded")
                self.assertFalse(paid["bank_data_collected"])
                from services.database import get_payment_request
                row=get_payment_request(self.conn,ctx.payment_request_id)
                self.assertEqual(row["status"],"succeeded")
                cols={r["name"] for r in self.conn.execute("PRAGMA table_info(payment_requests)")}
                self.assertNotIn("amount",cols)
                self.assertNotIn("transaction_id",cols)
            finally:
                if hasattr(self,"conn"): self.conn.close()
                os.chdir(old)

    def test_owner_can_reject_with_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            old=os.getcwd()
            try:
                app=self._app(tmp,AllowAdapter())
                ctx=app.run("Demo Learner","ai_fundamentals","Je veux m'inscrire.","Intéressé","text",True)
                result=app.reject_payment_request(ctx.payment_request_id,"Owner","Informations insuffisantes")
                self.assertEqual(result["status"],"rejected_by_owner")
                with self.assertRaises(PermissionError):
                    app.approve_payment_request(ctx.payment_request_id,"Owner")
            finally:
                if hasattr(self,"conn"): self.conn.close()
                os.chdir(old)

    def test_medium_security_review_requires_reason_and_owner_decision(self):
        with tempfile.TemporaryDirectory() as tmp:
            old=os.getcwd()
            try:
                app=self._app(tmp,ReviewAdapter())
                ctx=app.run("Demo Learner","ai_fundamentals","Je veux m'inscrire.","Intéressé","text",True)
                self.assertEqual(ctx.payment_result["status"],"pending_security")
                with self.assertRaises(ValueError):
                    app.review_security_request(ctx.payment_request_id,"Owner","")
                app.review_security_request(ctx.payment_request_id,"Owner","Vérification manuelle effectuée")
                result=app.approve_payment_request(ctx.payment_request_id,"Owner")
                self.assertEqual(result["status"],"approved_pending_customer_payment")
            finally:
                if hasattr(self,"conn"): self.conn.close()
                os.chdir(old)

if __name__ == "__main__":
    unittest.main()
