import unittest
from agents.customer_intelligence import CustomerIntelligenceAgent
from agents.offer_recommendation import OfferRecommendationAgent
from orchestrator import PRODUCTS

class CustomerIntelligenceTests(unittest.TestCase):
    def setUp(self):
        self.agent = CustomerIntelligenceAgent()

    def test_negated_interest_is_negative(self):
        result = self.agent.run("Je ne suis pas intéressée, c'est trop cher.", "Hésitant")
        self.assertEqual(result["sentiment"], "Négatif")

    def test_positive_intent(self):
        result = self.agent.run( "Je suis très intéressée et je veux m’inscrire à cette formation demain.", "Intéressé")
        self.assertEqual(result["sentiment"], "Positif")
        self.assertEqual(result["intent"], "strong_purchase_intent")

    def test_mixed_sentiment(self):
        result = self.agent.run( "Le service semble intéressant mais les frais sont trop chers.", "Hésitant")
        self.assertEqual(result["sentiment"], "Mitigé")

class OfferRecommendationTests(unittest.TestCase):
    def test_ai_need_recommends_ai_course(self):
        ci = CustomerIntelligenceAgent().run("Je veux apprendre le machine learning et l’intelligence artificielle.")
        result = OfferRecommendationAgent().recommend(
            "Je cherche une formation en intelligence artificielle et machine learning.",
            PRODUCTS, ci
        )
        self.assertEqual(result["recommendations"][0]["product_key"], "ai_fundamentals")

    def test_cloud_need_recommends_cloud_course(self):
        ci = CustomerIntelligenceAgent().run("Je veux apprendre les services cloud.")
        result = OfferRecommendationAgent().recommend(
            "Je cherche une formation cloud computing AWS et Azure.", PRODUCTS, ci
        )
        self.assertEqual(result["recommendations"][0]["product_key"], "cloud_computing")

class PaymentSafetyGateTests(unittest.TestCase):
    def test_payment_requires_security_and_human_approval(self):
        from agents.payment import PaymentAgent
        agent = PaymentAgent()
        waiting_security = agent.run(350, "TND", "Demo Customer", True)
        self.assertEqual(waiting_security["status"], "pending_security")
        self.assertIsNone(waiting_security["transaction_id"])

        waiting_human = agent.run(350, "TND", "Demo Customer", True,
                                 approved_by_security=True, human_approved=False)
        self.assertEqual(waiting_human["status"], "pending_human_approval")
        self.assertIsNone(waiting_human["transaction_id"])

        completed = agent.run(350, "TND", "Demo Customer", True,
                              approved_by_security=True, human_approved=True)
        self.assertEqual(completed["status"], "succeeded")
        self.assertTrue(completed["transaction_id"])

    def test_external_security_review_stops_payment_until_collaborator_allows(self):
        import os, tempfile
        from services.database import connect, fetch_payment_requests
        from orchestrator import FinTechOrchestrator

        class ReviewAdapter:
            def review(self, context):
                return {"decision":"review","risk_level":"medium",
                        "reasons":["Validation sécurité non terminée"],
                        "requires_human_approval":True}

        with tempfile.TemporaryDirectory() as tmp:
            old = os.getcwd()
            conn = None
            try:
                os.chdir(tmp)
                os.makedirs("data", exist_ok=True)
                conn = connect()
                ctx = FinTechOrchestrator(conn, security_adapter=ReviewAdapter()).run(
                    "Demo Customer", "ai_fundamentals",
                    "Je souhaite effectuer une opération de démonstration.", "Intéressé", "text", True
                )
                self.assertEqual(ctx.payment_result["status"], "pending_security")
                self.assertIsNone(ctx.payment_result["transaction_id"])
                reqs = fetch_payment_requests(conn)
                self.assertEqual(reqs[0]["status"], "pending_security")
            finally:
                if conn is not None:
                    conn.close()
                os.chdir(old)


    def test_payment_completes_only_after_security_allow_and_owner_approval(self):
        import os, tempfile
        from services.database import connect, fetch_payment_requests
        from orchestrator import FinTechOrchestrator

        class AllowAdapter:
            def review(self, context):
                return {"decision":"allow","risk_level":"low",
                        "reasons":["Contrôles de démonstration validés"],
                        "requires_human_approval":True}

        with tempfile.TemporaryDirectory() as tmp:
            old = os.getcwd()
            conn = None
            try:
                os.chdir(tmp)
                os.makedirs("data", exist_ok=True)
                conn = connect()
                app = FinTechOrchestrator(conn, security_adapter=AllowAdapter())
                ctx = app.run("Demo Customer", "ai_fundamentals",
                              "Je souhaite effectuer une opération.", "Intéressé", "text", True)
                self.assertEqual(ctx.payment_result["status"], "awaiting_owner_approval")
                self.assertIsNone(ctx.payment_result["transaction_id"])
                result = app.approve_payment_request(ctx.payment_request_id, "Owner Test")
                self.assertEqual(result["status"], "approved_pending_customer_payment")
                self.assertNotIn("transaction_id", result)
                req = fetch_payment_requests(conn)[0]
                self.assertEqual(req["status"], "approved_pending_customer_payment")
                self.assertEqual(req["human_approved_by"], "Owner Test")
                paid = app.complete_customer_payment(ctx.payment_request_id, customer_confirmed=True)
                self.assertEqual(paid["status"], "succeeded")
                self.assertFalse(paid["bank_data_collected"])
                req = fetch_payment_requests(conn)[0]
                self.assertEqual(req["status"], "succeeded")
                columns = {r["name"] for r in conn.execute("PRAGMA table_info(payment_requests)")}
                self.assertNotIn("amount", columns)
                self.assertNotIn("card_number", columns)
                self.assertNotIn("transaction_id", columns)
            finally:
                if conn is not None:
                    conn.close()
                os.chdir(old)



    def test_custom_transaction_override_uses_security_gate(self):
        import os, tempfile
        from services.database import connect, fetch_payment_requests
        from orchestrator import FinTechOrchestrator

        class ReviewAdapter:
            def review(self, context):
                self.context = context
                return {"decision": "review", "risk_level": "medium",
                        "reasons": ["Transaction à examiner"],
                        "requires_human_approval": True}

        with tempfile.TemporaryDirectory() as tmp:
            old = os.getcwd()
            conn = None
            try:
                os.chdir(tmp)
                os.makedirs("data", exist_ok=True)
                conn = connect()
                adapter = ReviewAdapter()
                app = FinTechOrchestrator(conn, security_adapter=adapter)
                custom = {
                    "id": "custom_wallet_transfer",
                    "name": "Transfert de portefeuille",
                    "price": 275.0,
                    "currency": "TND",
                    "description": "Transfert fictif",
                    "duration": "Ponctuel",
                    "format": "Simulation locale",
                    "audience": "Client démo",
                    "outcomes": ["Contrôle", "Traçabilité"]
                }
                ctx = app.run(
                    "Client Demo", "ai_fundamentals", "Je veux effectuer un transfert.",
                    "Intéressé", "text", True, product_override=custom
                )
                self.assertEqual(adapter.context["purpose"], "training_course_enrollment_demo")
                self.assertEqual(ctx.product["name"], "Transfert de portefeuille")
                self.assertEqual(ctx.payment_result["status"], "pending_security")
                self.assertNotIn("amount", fetch_payment_requests(conn)[0])
                from services.payment_vault import get_private_payment
                self.assertEqual(get_private_payment(fetch_payment_requests(conn)[0]["id"])["amount"], 275.0)
            finally:
                if conn is not None:
                    conn.close()
                os.chdir(old)

    def test_security_block_never_creates_executable_payment(self):
        import os, tempfile
        from services.database import connect, fetch_payment_requests
        from orchestrator import FinTechOrchestrator

        class BlockAdapter:
            def review(self, context):
                return {"decision": "block", "risk_level": "high",
                        "reasons": ["Règle de risque déclenchée"],
                        "requires_human_approval": False}

        with tempfile.TemporaryDirectory() as tmp:
            old = os.getcwd()
            conn = None
            try:
                os.chdir(tmp)
                os.makedirs("data", exist_ok=True)
                conn = connect()
                app = FinTechOrchestrator(conn, security_adapter=BlockAdapter())
                ctx = app.run(
                    "Client Demo", "ai_fundamentals", "Transaction suspecte de démonstration.",
                    "Intéressé", "text", True
                )
                self.assertEqual(ctx.payment_result["status"], "blocked_by_security")
                self.assertIsNone(ctx.payment_result["transaction_id"])
                with self.assertRaises(PermissionError):
                    app.approve_payment_request(ctx.payment_request_id, "Owner Test")
                self.assertEqual(fetch_payment_requests(conn)[0]["status"], "blocked_by_security")
            finally:
                if conn is not None:
                    conn.close()
                os.chdir(old)

    def test_security_failure_is_fail_closed(self):
        import os, tempfile
        from services.database import connect
        from orchestrator import FinTechOrchestrator

        class BrokenAdapter:
            def review(self, context):
                raise RuntimeError("security unavailable")

        with tempfile.TemporaryDirectory() as tmp:
            old = os.getcwd()
            conn = None
            try:
                os.chdir(tmp)
                os.makedirs("data", exist_ok=True)
                conn = connect()
                ctx = FinTechOrchestrator(conn, security_adapter=BrokenAdapter()).run(
                    "Client Demo", "ai_fundamentals", "Test opération.",
                    "Intéressé", "text", True
                )
                self.assertEqual(ctx.security_result["decision"], "review")
                self.assertEqual(ctx.payment_result["status"], "pending_security")
                self.assertIsNone(ctx.payment_result["transaction_id"])
            finally:
                if conn is not None:
                    conn.close()
                os.chdir(old)

class SalesAssistantTests(unittest.TestCase):
    def test_assistant_answers_service_features(self):
        from agents.sales import SalesAgent
        from orchestrator import PRODUCTS
        result = SalesAgent().run("Amira", PRODUCTS["ai_fundamentals"], "Quelles sont les fonctionnalités ?")
        self.assertIn("Préparation des données", result["message"])
        self.assertEqual(result["assistant_mode"], "catalogue_faq_local")

    def test_assistant_explains_security_first_payment_flow(self):
        from agents.sales import SalesAgent
        from orchestrator import PRODUCTS
        result = SalesAgent().run("Amira", PRODUCTS["cybersecurity"], "Comment se passe la sécurité et le paiement de la formation ?")
        self.assertIn("contrôle de sécurité", result["message"])


class DemoPaymentStatusTests(unittest.TestCase):
    def test_demo_provider_can_represent_all_required_statuses(self):
        from agents.payment import DemoPaymentProvider
        for status in ("succeeded", "failed", "pending"):
            result = DemoPaymentProvider(status).create_payment(300, "TND", "Demo")
            self.assertEqual(result["status"], status)
            self.assertTrue(result["transaction_id"])
            self.assertEqual(result["provider"], "local_demo")


if __name__ == "__main__":
    unittest.main()
