import unittest
from agents.offer_recommendation import OfferRecommendationAgent
from agents.sales import SalesAgent
from orchestrator import PRODUCTS

class V12ConversationAndRecommendationTests(unittest.TestCase):
    def test_rag_question_gets_contextual_explanation_and_scope_disclaimer(self):
        result = SalesAgent().run("Amira", PRODUCTS["ai_fundamentals"], "Je veux étudier le RAG")
        self.assertIn("Retrieval-Augmented Generation", result["message"])
        self.assertIn("ne confirme pas", result["message"])

    def test_short_yes_uses_previous_assistant_context(self):
        history = [{"role": "assistant", "content": "Souhaitez-vous apprendre avec un projet pratique ?"}]
        result = SalesAgent().run("Amira", PRODUCTS["ai_fundamentals"], "oui", conversation_history=history)
        self.assertIn("préciser votre besoin", result["message"])

    def test_rag_recommends_ai_not_unrelated_courses(self):
        result = OfferRecommendationAgent().recommend(
            "Je veux apprendre le RAG avec Python, je suis débutant et je veux construire un chatbot.",
            PRODUCTS
        )
        self.assertTrue(result["recommendations"])
        self.assertEqual(result["recommendations"][0]["product_key"], "ai_fundamentals")
        self.assertFalse(any(x["product_key"] == "cloud_computing" for x in result["recommendations"]))

    def test_vague_goal_does_not_return_random_top_three(self):
        result = OfferRecommendationAgent().recommend("Je veux apprendre quelque chose", PRODUCTS)
        self.assertEqual(result["recommendations"], [])
        self.assertTrue(result["needs_clarification"])
        self.assertTrue(result["clarifying_questions"])

    def test_budget_can_change_ranking(self):
        result = OfferRecommendationAgent().recommend(
            "Je veux apprendre le cloud, je suis débutant, budget 450 TND", PRODUCTS
        )
        self.assertEqual(result["recommendations"][0]["product_key"], "cloud_computing")
        self.assertTrue(any("budget" in r.lower() for r in result["recommendations"][0]["reasons"]))

if __name__ == "__main__":
    unittest.main()
