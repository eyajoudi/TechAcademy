import json
from datetime import datetime, timedelta
from services.database import save_interaction, save_event

def seed_demo_data(conn):
    """Insert clearly synthetic training-centre journeys once, only when the DB is empty."""
    count = conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0]
    if count:
        return False
    samples = [
        ("Amira Ben Salah","Intelligence artificielle & Machine Learning",450,"Intéressé","Positif","text","succeeded","Prix / budget","Évoluer vers l’IA"),
        ("Youssef Trabelsi","Cybersécurité & Ethical Hacking",520,"Intéressé","Positif","voice","succeeded","Disponibilité / temps","Développer des compétences cyber"),
        ("Sarra Mansour","Cloud Computing & AWS/Azure Fundamentals",490,"Hésitant","Neutre / incertain","text","pending_review","Prérequis / niveau","Se spécialiser dans le cloud"),
        ("Ahmed Gharbi","DevOps & CI/CD",480,"Intéressé","Positif","text","succeeded","Aucune objection explicite détectée","Automatiser les déploiements"),
        ("Meriem Khelifi","DevSecOps & Secure Software Delivery",560,"Pas intéressé","Négatif","text","not_started","Prix / budget","Sécuriser le développement"),
        ("Nour Jaziri","Data Science & Business Intelligence",460,"Intéressé","Positif","voice","succeeded","Prérequis / niveau","Maîtriser l’analyse de données"),
        ("Omar Saidi","Programmation Python & Développement logiciel",390,"Hésitant","Neutre / incertain","text","failed","Disponibilité / temps","Apprendre à programmer"),
        ("Rania Hadded","Cybersécurité & Ethical Hacking",520,"Intéressé","Positif","text","succeeded","Aucune objection explicite détectée","Préparer une certification"),
        ("Fares Ayari","Cloud Computing & AWS/Azure Fundamentals",490,"Intéressé","Positif","text","succeeded","Disponibilité / temps","Évoluer vers le cloud"),
        ("Ines Chaabane","Intelligence artificielle & Machine Learning",450,"Hésitant","Neutre / incertain","voice","pending_review","Prix / budget","Découvrir le Machine Learning"),
        ("Malek Bousnina","DevOps & CI/CD",480,"Intéressé","Positif","text","succeeded","Aucune objection explicite détectée","Maîtriser Docker et CI/CD"),
        ("Lina Dridi","DevSecOps & Secure Software Delivery",560,"Pas intéressé","Négatif","text","not_started","Prérequis / niveau","Relier développement et sécurité"),
        ("Adam Ben Amor","Programmation Python & Développement logiciel",390,"Intéressé","Positif","text","succeeded","Aucune objection explicite détectée","Commencer la programmation"),
        ("Yasmine Rekik","Data Science & Business Intelligence",460,"Hésitant","Neutre / incertain","text","pending_review","Disponibilité / temps","Analyser des données"),
        ("Sami Bouaziz","Cybersécurité & Ethical Hacking",520,"Intéressé","Positif","voice","succeeded","Aucune objection explicite détectée","Apprendre la sécurité réseau"),
        ("Dorra Kammoun","Intelligence artificielle & Machine Learning",450,"Intéressé","Positif","text","succeeded","Prix / budget","Construire des modèles IA"),
        ("Bilel Mzoughi","Cloud Computing & AWS/Azure Fundamentals",490,"Pas intéressé","Négatif","text","not_started","Prix / budget","Comprendre le cloud"),
        ("Hiba Saïdi","DevOps & CI/CD",480,"Intéressé","Positif","text","succeeded","Aucune objection explicite détectée","Apprendre l’intégration continue")
    ]
    now = datetime.now()
    for i, sample in enumerate(samples):
        name, course, amount, interest, sentiment, channel, status, objection, motivation = sample
        run_id = f"DEMO-RUN-{i+1:03d}"
        created = now - timedelta(days=(17-i) % 14, hours=(i*3) % 12)
        transaction_id = f"DEMO-TXN-{i+1:04d}" if status == "succeeded" else None
        messages = {
            "Prix / budget": "La formation m’intéresse, mais le tarif est un peu élevé.",
            "Disponibilité / temps": "La formation m’intéresse, mais je dois vérifier mon emploi du temps.",
            "Prérequis / niveau": "Je souhaite savoir si cette formation est adaptée à mon niveau.",
            "Aucune objection explicite détectée": "Je souhaite découvrir le programme, les projets pratiques et les compétences acquises."
        }
        message = messages[objection]
        analysis = {"sentiment": sentiment, "sentiment_score": 78 if sentiment == "Positif" else 48 if sentiment.startswith("Neutre") else 22,
                    "sentiment_confidence": 76, "intent": "enrollment_intent" if interest == "Intéressé" else "needs_clarification",
                    "intent_label": "Intention d’inscription" if interest == "Intéressé" else "Demande d’information / hésitation",
                    "intent_score": 88 if interest == "Intéressé" else 58,
                    "emotions": ["Intérêt / enthousiasme"] if sentiment == "Positif" else ["Hésitation / préoccupation"],
                    "urgency": "Normale", "objections": [objection], "motivations": [motivation],
                    "evidence": ["Exemple synthétique créé pour la démonstration"],
                    "next_best_action": "Présenter le programme, les prérequis et les modalités de la formation."}
        save_interaction(conn, {"customer_name": name, "product_name": course, "amount": amount, "currency": "TND",
            "channel": channel, "interest_level": interest, "sentiment": sentiment, "objections": [objection],
            "motivations": [motivation], "payment_status": status, "transaction_id": transaction_id,
            "provider": "synthetic_demo" if status == "succeeded" else "not_applicable",
            "recommendations": ["Présenter les compétences visées et répondre à l’objection principale."],
            "customer_message": message, "sales_reply": f"Merci {name}. Voici les informations relatives à {course}.",
            "run_id": run_id, "customer_analysis": analysis})
        conn.execute("UPDATE interactions SET created_at=? WHERE run_id=?", (created.isoformat(timespec="seconds"), run_id))
        event_items = [("Voice Sales Agent","course_presented","completed"),("Customer Intelligence Agent","learner_profile_created","completed"),
            ("Offer Recommendation Agent","courses_ranked","completed"),("ML Fraud Detection Agent","risk_scoring_demo","synthetic_demo"),
            ("Security & Fraud Detection Agent (external)","security_review","external_pending"),("Payment Agent","enrollment_payment_result","demo_history"),
            ("Financial Intelligence Agent","training_revenue_insights","completed"),("Business Strategy Agent","recommendations_generated","completed")]
        for j, (agent,event,status_event) in enumerate(event_items):
            save_event(conn, run_id, agent, event, {"demo_data": True, "note": "Événement fictif préchargé pour illustrer le dashboard."}, status_event, duration_ms=8.5+j*4.2)
            conn.execute("UPDATE agent_events SET created_at=? WHERE run_id=? AND agent_name=?",
                ((created+timedelta(milliseconds=j*150)).isoformat(timespec="milliseconds"),run_id,agent))
    conn.commit()
    return True
