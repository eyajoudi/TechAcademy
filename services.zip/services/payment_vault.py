"""Private payment ledger, separate from the Owner operational database.
No card number, CVV, PIN or bank credential is collected or stored.
"""
import sqlite3
from pathlib import Path
from datetime import datetime

VAULT_FILE = Path("data/private_payment_ledger.db")
VAULT_FILE.parent.mkdir(parents=True, exist_ok=True)

def _connect():
    c=sqlite3.connect(VAULT_FILE, check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS private_payments (
      request_id INTEGER PRIMARY KEY, customer_reference TEXT, amount REAL NOT NULL,
      currency TEXT NOT NULL, status TEXT NOT NULL, transaction_id TEXT, provider TEXT,
      updated_at TEXT NOT NULL)""")
    c.commit()
    return c

def store_payment_request(request_id, customer_reference, amount, currency, status):
    c=_connect()
    try:
        c.execute("INSERT OR REPLACE INTO private_payments VALUES(?,?,?,?,?,?,?,?)",
          (int(request_id), str(customer_reference), float(amount), str(currency), str(status), None, None, datetime.now().isoformat(timespec="seconds")))
        c.commit()
    finally: c.close()

def get_private_payment(request_id):
    c=_connect()
    try:
        row=c.execute("SELECT * FROM private_payments WHERE request_id=?",(int(request_id),)).fetchone()
        return dict(row) if row else None
    finally: c.close()

def update_private_payment(request_id, result):
    c=_connect()
    try:
        c.execute("UPDATE private_payments SET status=?,transaction_id=?,provider=?,updated_at=? WHERE request_id=?",
          (result.get("status"),result.get("transaction_id"),result.get("provider"),datetime.now().isoformat(timespec="seconds"),int(request_id)))
        c.commit()
    finally: c.close()


def update_private_payment_status(request_id, status):
    c = _connect()
    try:
        c.execute("UPDATE private_payments SET status=?,updated_at=? WHERE request_id=?",
                  (str(status), datetime.now().isoformat(timespec="seconds"), int(request_id)))
        c.commit()
    finally:
        c.close()
