import io

def transcribe_audio(audio_bytes):
    import speech_recognition as sr
    recognizer = sr.Recognizer()
    recognizer.operation_timeout = 8
    with sr.AudioFile(io.BytesIO(audio_bytes)) as source:
        audio = recognizer.record(source)
    return recognizer.recognize_google(audio, language="fr-FR")

def synthesize_speech(text):
    from gtts import gTTS
    out = io.BytesIO()
    gTTS(text=text, lang="fr", timeout=(4, 8)).write_to_fp(out)
    out.seek(0)
    return out.read()
