import sqlite3, json
from pathlib import Path
from datetime import datetime

DB_FILE = Path("data/techacademy_training.db")
DB_FILE.parent.mkdir(parents=True, exist_ok=True)

def connect():
    conn = sqlite3.connect(DB_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("""
    CREATE TABLE IF NOT EXISTS interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        customer_name TEXT,
        product_name TEXT,
        amount REAL,
        currency TEXT,
        channel TEXT,
        interest_level TEXT,
        sentiment TEXT,
        objections_json TEXT,
        motivations_json TEXT,
        payment_status TEXT,
        transaction_id TEXT,
        provider TEXT,
        recommendations_json TEXT,
        customer_message TEXT,
        sales_reply TEXT,
        run_id TEXT,
        analysis_json TEXT
    )""")
    conn.execute("""
    CREATE TABLE IF NOT EXISTS agent_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        run_id TEXT,
        agent_name TEXT,
        event_type TEXT,
        status TEXT,
        duration_ms REAL,
        payload_json TEXT
    )""")
    conn.execute("""
    CREATE TABLE IF NOT EXISTS payment_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        run_id TEXT UNIQUE,
        product_id TEXT,
        product_name TEXT,
        security_decision TEXT,
        risk_level TEXT,
        security_reasons_json TEXT,
        status TEXT,
        human_approved_by TEXT,
        reviewed_at TEXT,
        owner_assessment TEXT,
        owner_assessment_reason TEXT
    )""")
    conn.commit()
    
    existing = {r["name"] for r in conn.execute("PRAGMA table_info(interactions)").fetchall()}
    for col, typ in [
        ("customer_message", "TEXT"), ("sales_reply", "TEXT"), ("run_id", "TEXT"),
        ("recommendations_json", "TEXT"), ("analysis_json", "TEXT")
    ]:
        if col not in existing:
            conn.execute(f"ALTER TABLE interactions ADD COLUMN {col} {typ}")
    event_cols = {r["name"] for r in conn.execute("PRAGMA table_info(agent_events)").fetchall()}
    for col, typ in [("status", "TEXT"), ("duration_ms", "REAL")]:
        if col not in event_cols:
            conn.execute(f"ALTER TABLE agent_events ADD COLUMN {col} {typ}")
    # Migrate legacy Owner payment_requests table to a minimized schema.
    payment_cols = {r["name"] for r in conn.execute("PRAGMA table_info(payment_requests)").fetchall()}
    safe_cols = {"id", "created_at", "run_id", "product_id", "product_name", "security_decision", "risk_level", "security_reasons_json", "status", "human_approved_by", "reviewed_at", "owner_assessment", "owner_assessment_reason"}
    if not safe_cols.issubset(payment_cols) or (payment_cols - safe_cols):
        conn.execute("ALTER TABLE payment_requests RENAME TO payment_requests_legacy")
        conn.execute("""CREATE TABLE payment_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, run_id TEXT UNIQUE,
            product_id TEXT, product_name TEXT, security_decision TEXT, risk_level TEXT,
            security_reasons_json TEXT, status TEXT, human_approved_by TEXT, reviewed_at TEXT,
            owner_assessment TEXT, owner_assessment_reason TEXT)""")
        legacy_cols = {r["name"] for r in conn.execute("PRAGMA table_info(payment_requests_legacy)").fetchall()}
        common = [c for c in ("id", "created_at", "run_id", "product_id", "product_name", "security_decision", "risk_level", "security_reasons_json", "status", "human_approved_by", "reviewed_at") if c in legacy_cols]
        if common:
            names = ",".join(common)
            conn.execute(f"INSERT INTO payment_requests ({names}) SELECT {names} FROM payment_requests_legacy")
        conn.execute("DROP TABLE payment_requests_legacy")
    # Legacy transaction identifiers are removed from the Owner-facing interactions store.
    conn.execute("UPDATE interactions SET transaction_id=NULL, provider=NULL")
    conn.commit()
    return conn

def save_event(conn, run_id, agent_name, event_type, payload, status="completed", duration_ms=None):
    conn.execute("""
    INSERT INTO agent_events(created_at,run_id,agent_name,event_type,status,duration_ms,payload_json)
    VALUES(?,?,?,?,?,?,?)""",
    (datetime.now().isoformat(timespec="seconds"), run_id, agent_name, event_type,
     status, duration_ms, json.dumps(payload, ensure_ascii=False, default=str)))
    conn.commit()

def save_interaction(conn, record):
    conn.execute("""
    INSERT INTO interactions(created_at,customer_name,product_name,amount,currency,channel,
    interest_level,sentiment,objections_json,motivations_json,payment_status,transaction_id,
    provider,recommendations_json,customer_message,sales_reply,run_id,analysis_json)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    (datetime.now().isoformat(timespec="seconds"), record.get("customer_name"),
     record.get("product_name"), record.get("amount"), record.get("currency"),
     record.get("channel"), record.get("interest_level"), record.get("sentiment"),
     json.dumps(record.get("objections", []), ensure_ascii=False),
     json.dumps(record.get("motivations", []), ensure_ascii=False),
     record.get("payment_status"), record.get("transaction_id"), record.get("provider"),
     json.dumps(record.get("recommendations", []), ensure_ascii=False),
     record.get("customer_message"), record.get("sales_reply"), record.get("run_id"),
     json.dumps({**record.get("customer_analysis", {}),
                 "offer_recommendations": record.get("offer_recommendations", [])}, ensure_ascii=False)))
    conn.commit()

def fetch_interactions(conn):
    rows = conn.execute("SELECT * FROM interactions ORDER BY id DESC").fetchall()
    result = []
    for row in rows:
        d = dict(row)
        d["objections"] = json.loads(d.pop("objections_json") or "[]")
        d["motivations"] = json.loads(d.pop("motivations_json") or "[]")
        d["recommendations"] = json.loads(d.pop("recommendations_json") or "[]")
        d["customer_analysis"] = json.loads(d.pop("analysis_json") or "{}")
        d["offer_recommendations"] = d["customer_analysis"].get("offer_recommendations", [])
        result.append(d)
    return result

def fetch_events(conn, limit=500):
    rows = conn.execute("SELECT * FROM agent_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def create_payment_request(conn, record):
    """Owner DB stores workflow metadata only, never payment amount/reference/transaction data."""
    cur = conn.execute("""
    INSERT INTO payment_requests(
        created_at,run_id,product_id,product_name,security_decision,risk_level,
        security_reasons_json,status,owner_assessment,owner_assessment_reason
    ) VALUES(?,?,?,?,?,?,?,?,?,?)
    """, (
        datetime.now().isoformat(timespec="seconds"), record["run_id"],
        record["product_id"], record["product_name"], record.get("security_decision","review"),
        record.get("risk_level","unknown"), json.dumps(record.get("security_reasons",[]), ensure_ascii=False),
        record.get("status","pending_security"), record.get("owner_assessment","manual_review"),
        record.get("owner_assessment_reason", "")
    ))
    conn.commit()
    return cur.lastrowid

def fetch_payment_requests(conn):
    rows = conn.execute("SELECT * FROM payment_requests ORDER BY id DESC").fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["security_reasons"] = json.loads(item.pop("security_reasons_json") or "[]")
        result.append(item)
    return result

def update_payment_request(conn, request_id, status, approved_by=None, assessment=None, reason=None):
    conn.execute("""UPDATE payment_requests SET status=?, human_approved_by=?, reviewed_at=?,
        owner_assessment=COALESCE(?,owner_assessment), owner_assessment_reason=COALESCE(?,owner_assessment_reason)
        WHERE id=?""", (status, approved_by,
        datetime.now().isoformat(timespec="seconds") if approved_by else None,
        assessment, reason, request_id))
    conn.commit()


def get_payment_request(conn, request_id):
    row = conn.execute("SELECT * FROM payment_requests WHERE id=?", (int(request_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["security_reasons"] = json.loads(item.pop("security_reasons_json") or "[]")
    return item


def transition_payment_request(conn, request_id, expected_status, new_status,
                               security_decision=None, reviewer=None, reason=None):
    """Compare-and-set transition to prevent duplicate or stale approvals."""
    cur = conn.execute(
        """UPDATE payment_requests
           SET status=?, security_decision=COALESCE(?,security_decision),
               human_approved_by=COALESCE(?,human_approved_by),
               reviewed_at=?, owner_assessment=COALESCE(?,owner_assessment),
               owner_assessment_reason=COALESCE(?,owner_assessment_reason)
           WHERE id=? AND status=?""",
        (new_status, security_decision, reviewer,
         datetime.now().isoformat(timespec="seconds"), None, reason,
         int(request_id), expected_status)
    )
    conn.commit()
    return cur.rowcount == 1
