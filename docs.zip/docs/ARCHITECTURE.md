# Architecture V9 — TechAcademy AI Squad

```mermaid
flowchart TD
  A[Prospect / apprenant] --> UI[Client Portal]
  O[Owner / responsable] --> DASH[Owner Console]
  UI --> ORCH[Training Center Orchestrator]
  ORCH --> SALES[Voice Sales Agent]
  ORCH --> CI[Customer Intelligence Agent]
  ORCH --> NLP[Advanced Customer AI]
  ORCH --> REC[Offer Recommendation Agent]
  ORCH --> FRAUD[ML Fraud Detection Agent]
  FRAUD --> SEC[Security Adapter externe]
  SEC -->|allow| HUMAN[Validation Owner]
  SEC -->|review| HOLD[En attente]
  SEC -->|block| STOP[Blocage]
  HUMAN --> PAY[Payment Agent / simulateur]
  PAY --> KPI[Financial Data Analyst]
  KPI --> FI[Financial Intelligence]
  CI --> STRAT[Business Strategy Agent]
  FI --> STRAT
  STRAT --> DASH
  ORCH --> DB[(SQLite / événements)]
  PAY --> DB
  KPI --> DB
  DASH --> DB
```

## Séquence d'inscription

```mermaid
sequenceDiagram
  participant L as Prospect
  participant O as Orchestrateur
  participant C as Agents Client/NLP
  participant R as Recommandation
  participant F as ML Fraud
  participant S as Security externe
  participant H as Owner
  participant P as Payment simulé
  participant I as Financial Intelligence
  L->>O: Besoin et demande d'inscription
  O->>C: Analyse profil, sentiment, objections
  O->>R: Classement des formations
  R-->>L: Formations recommandées
  L->>O: Confirmation demande fictive
  O->>F: Signaux de la demande
  F-->>O: Score et explications
  O->>S: Contexte + score ML
  alt block
    S-->>O: block
    O-->>L: Demande bloquée
  else review
    S-->>O: review
    O-->>L: Demande en attente
  else allow
    S-->>O: allow
    O->>H: Demande à valider
    H-->>O: Approbation explicite
    O->>P: Simuler règlement
    P-->>O: succeeded / failed / pending
    O->>I: Données consolidées
    I-->>O: KPI et insights
  end
```

## Principes
- Un orchestrateur central partage un contexte structuré entre agents.
- Chaque agent a une responsabilité métier définie.
- Le moteur sécurité externe reste indépendant et doit être fourni par le membre de l'équipe chargé de la cybersécurité.
- `review`, `block`, exception ou réponse invalide interdisent la simulation de règlement.
- `allow` n'est pas suffisant : la validation Owner reste obligatoire.
- La base SQLite contient des données de démonstration et un journal d'événements.
