# Fiche projet

La fiche détaillée de référence pour la V9 est `PROJECT_BRIEF_A_TO_Z.md`. Elle remplace le dossier FinTech AI Squad V8 antérieur et décrit le scénario centre de formation informatique.
