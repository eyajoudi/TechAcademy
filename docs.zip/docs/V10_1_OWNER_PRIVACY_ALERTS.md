# V10.1 — Owner review, payment privacy and alerts

## Automated Owner assessment
The orchestrator assigns a recommendation to every payment request:
- `eligible_for_owner_confirmation`: security decision is allow and ML risk is not medium/high.
- `manual_review`: a review decision or medium ML risk exists.
- `reject_or_escalate`: security block or high ML risk exists.

This is an automated assessment aid, not autonomous payment approval. The Owner must still explicitly confirm the local simulated payment. A blocked or review request cannot be executed.

## Payment-data separation
The Owner operational database (`data/techacademy_training.db`) stores only payment workflow metadata: request ID, run ID, course, security decision, risk, reasons, status and Owner review metadata. It no longer stores amount, currency, customer payment reference, provider transaction ID or provider name in `payment_requests`.

A separate local ledger (`data/private_payment_ledger.db`) stores the demo payment amount, currency, customer reference, status and provider transaction identifier. It is a separate SQLite file, not an encrypted production vault. No card number, CVV, PIN or bank credential is collected or stored anywhere.

Legacy `payment_requests` tables are migrated to a minimized schema; old transaction IDs/provider values are cleared from Owner interaction records.

## Owner alerts
The Overview KPI now shows `Alertes sécurité`; the old `Sentiments positifs` KPI was removed. Security block/review/error decisions, ML review overrides and input-guard review events are counted. The Owner sees a warning banner when security events require attention.

## Production caveat
For real deployment, move the private ledger behind a dedicated payment service/database, apply encryption at rest, service-level authorization, secrets management, retention policies and audit controls. This demo does not process real payments.

## V10.2 — Scoring Enrollment Risk & Fraud automatisé

- Suppression du formulaire manuel de simulation (montant, heure, vélocité, tentatives, appareil, distance et incohérence).
- Le scoring est déclenché automatiquement lors d'une demande d'inscription avec paiement confirmée.
- Le montant vient du catalogue de formations ; l'heure vient de l'horodatage serveur ; la vélocité est calculée depuis les demandes de paiement récentes ; les tentatives échouées sont comptées dans les interactions des dernières 24 heures.
- Les signaux appareil et géolocalisation ne sont pas collectés dans cette démonstration : des valeurs neutres sont utilisées et leur indisponibilité est affichée explicitement. L'incohérence marchand/opération n'est pas applicable au scénario du centre de formation.
- La page affiche le dernier score, les facteurs explicatifs, les variables et l'historique des évaluations enregistrées. Elle n'exécute aucune action de paiement.
