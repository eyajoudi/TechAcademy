# DOSSIER COMPLET DU PROJET — TECHACADEMY AI SQUAD V9

## Titre officiel
**TechAcademy AI Squad — Autonomous Multi-Agent Training & Enrollment Platform**

**Sous-titre :** Une équipe d'agents intelligents pour conseiller les apprenants, recommander des formations informatiques, sécuriser les inscriptions et piloter la performance d'un centre de formation.

**Contexte :** Hackathon « The Autonomous FinTech Team » — TechX ENIT x ENICarthage. Le projet utilise un centre de formation comme scénario métier concret pour démontrer les compétences FinTech, l'IA agentique, la Data & BI et la cybersécurité.

---

## 1. Résumé exécutif

TechAcademy AI Squad est un prototype web multi-agents destiné à un centre de formation spécialisé dans les métiers de l'informatique. Le centre propose un catalogue de parcours en Intelligence Artificielle et Machine Learning, Cybersécurité, Cloud Computing, DevOps, DevSecOps, Data Science & Business Intelligence et Programmation Python.

La plateforme accompagne le parcours d'un prospect depuis sa première question jusqu'à sa demande d'inscription. Des agents spécialisés comprennent son besoin, analysent son niveau et ses motivations, répondent à ses questions, recommandent les formations les plus pertinentes, évaluent le risque d'une demande de règlement, demandent un contrôle de sécurité et une validation humaine, puis alimentent les indicateurs de pilotage du centre.

Les paiements sont exclusivement simulés dans cette version. Les données de démonstration sont fictives. Le projet ne collecte aucune donnée de carte bancaire ou d'identification bancaire.

## 2. Problématique

Les centres de formation informatique proposent souvent plusieurs parcours dont les prérequis, les durées, les tarifs, les objectifs et les débouchés sont différents. Un prospect peut ne pas savoir quelle formation choisir, si son niveau est suffisant, ni quel parcours correspond à son projet professionnel. Du côté du centre, le suivi des demandes, des objections, des inscriptions, des règlements et de la performance commerciale peut être fragmenté.

**Problématique :** Comment concevoir une plateforme multi-agents intelligente capable d'accompagner un prospect dans le choix d'une formation informatique, d'automatiser et sécuriser le parcours d'inscription, puis de transformer les données commerciales et financières du centre en recommandations opérationnelles ?

## 3. Objectif général

Construire un assistant opérationnel multi-agents pour un centre de formation informatique, capable de relier l'expérience apprenant, la recommandation pédagogique, le contrôle des inscriptions payantes et l'aide à la décision du gestionnaire.

### Objectifs spécifiques

1. Présenter les formations à partir d'un catalogue structuré et vérifiable.
2. Comprendre les objectifs, le niveau, les contraintes et les objections du prospect.
3. Classifier les messages et extraire des thèmes grâce au NLP.
4. Recommander des formations avec une méthode explicable.
5. Gérer une demande d'inscription et simuler son règlement.
6. Évaluer le risque d'une opération avec un modèle de Machine Learning.
7. Connecter le résultat à un module de sécurité qui décide `allow`, `review` ou `block`.
8. Exiger une validation humaine avant toute simulation de paiement autorisée.
9. Mesurer les inscriptions, les conversions, les revenus simulés et les performances par formation.
10. Générer des recommandations pour améliorer le catalogue et le parcours prospect.

## 4. Périmètre fonctionnel et catalogue

Le catalogue initial comprend sept formations fictives, avec tarifs et durées indicatifs pour la démonstration :

| Formation | Durée indicative | Tarif démo | Compétences / résultats visés |
|---|---:|---:|---|
| Intelligence artificielle & Machine Learning | 8 semaines | 450 TND | Python pour l'IA, préparation des données, classification, régression, évaluation |
| Cybersécurité & Ethical Hacking | 10 semaines | 520 TND | Réseaux, Linux, analyse de vulnérabilités en laboratoire autorisé, réponse aux incidents |
| Cloud Computing & AWS/Azure Fundamentals | 8 semaines | 490 TND | IaaS/PaaS/SaaS, déploiement cloud, réseaux virtuels, sécurité et coûts |
| DevOps & CI/CD | 9 semaines | 480 TND | Git, Linux, Docker, pipelines CI/CD |
| DevSecOps & Secure Software Delivery | 8 semaines | 560 TND | Secure SDLC, analyse statique, dépendances, pipelines sécurisés |
| Data Science & Business Intelligence | 8 semaines | 460 TND | Python, Pandas, nettoyage, visualisation, Power BI, KPI |
| Programmation Python & Développement logiciel | 7 semaines | 390 TND | Bases Python, algorithmique, POO, mini-applications |

Les tarifs, durées, formats et publics sont des données de démonstration à remplacer par les informations officielles du centre.

### Hors périmètre de cette version

- Gestion réelle des présences, des notes et des certificats.
- LMS complet, classes virtuelles et dépôt de devoirs.
- Paiement bancaire réel ou conservation de données de carte.
- Authentification de production et gestion complète des rôles.
- Validation de la qualité pédagogique des formations par un organisme externe.

## 5. Utilisateurs et rôles

### Prospect / apprenant
- Pose des questions par texte ou voix selon les capacités installées.
- Décrit ses objectifs, son niveau et ses contraintes.
- Consulte le catalogue et les recommandations.
- Soumet une demande d'inscription fictive.
- Reçoit le statut de la demande.

### Owner / responsable du centre
- Consulte les indicateurs et le tableau de bord.
- Examine les demandes d'inscription et les alertes.
- Valide manuellement une demande après contrôle sécurité.
- Suit le revenu simulé, la conversion et la performance des formations.
- Consulte les recommandations stratégiques.

Le sélecteur Owner/Client de démonstration est une séparation d'interface, pas une authentification ni une autorisation serveur de production.

## 6. Les agents et leurs responsabilités

### 6.1 Voice Sales Agent / conseiller pédagogique
Présente le catalogue, répond aux questions documentées sur le prix, la durée, le format, les prérequis, les objectifs et le public visé. Il peut utiliser un mode conversationnel local et, si configuré, un LLM externe. Il ne doit jamais inventer une condition commerciale ou un diplôme.

### 6.2 Customer Intelligence Agent
Analyse les messages et le niveau d'intérêt. Il détecte les signaux d'intérêt, les objections (prix, disponibilité, niveau, confiance), les motivations et la prochaine action conseillée. La version actuelle repose sur des règles lexicales explicables.

### 6.3 Advanced Customer AI Agent
Utilise TF-IDF et Logistic Regression pour classer un message en positif, négatif, neutre ou mitigé. Il extrait des thèmes liés au contenu de formation, au prix, au niveau, aux horaires, à la carrière et aux technologies. Le corpus actuel est petit et synthétique : ses scores sont indicatifs.

### 6.4 Offer Recommendation Agent
Classe les formations selon les mots-clés et objectifs détectés, les résultats pédagogiques du catalogue et le budget facultatif. Il explique les correspondances et indique lorsqu'une clarification est nécessaire. Il s'agit d'un moteur de recommandation par contenu, pas d'un modèle de recommandation entraîné sur un historique réel.

### 6.5 ML Fraud Detection Agent
Utilise un RandomForestClassifier entraîné sur des événements artificiels pour produire un score de risque de 0 à 100 et un niveau faible, moyen ou élevé. Les variables de démonstration comprennent le montant, l'heure, la fréquence des demandes, les tentatives échouées, le nouvel appareil, l'écart géographique et une incohérence de contexte. Dans le cas du centre, ces signaux servent à illustrer la détection d'opérations d'inscription ou de règlement atypiques.

Ce modèle n'est ni validé sur des fraudes réelles ni destiné à accuser un apprenant. Il ne décide jamais seul d'autoriser un règlement. Un modèle de production exigerait des données représentatives, une définition documentée de la fraude, une validation statistique, une analyse des biais et une surveillance continue.

### 6.6 Security & Fraud Detection Agent / adaptateur externe
Reçoit le contexte de la demande et le résultat ML. Il doit appliquer les règles de sécurité et retourner `allow`, `review` ou `block`, avec motifs et niveau de risque. L'adaptateur présent dans le dépôt est un contrat d'intégration ; le moteur réel du coéquipier doit encore être branché et testé.

### 6.7 Payment Agent
Gère les statuts de demande et appelle le fournisseur de paiement local simulé uniquement après `allow` et validation humaine du Owner. Il représente les statuts `succeeded`, `failed` et `pending`. Aucun mouvement d'argent réel n'est effectué.

### 6.8 Financial Data Analyst
Agrège les interactions et demandes : nombre de prospects, intérêt, conversion, inscriptions, statuts et revenu simulé.

### 6.9 Financial Intelligence Agent
Calcule le revenu simulé, le ticket moyen, le taux de réussite, le taux d'échec, les demandes en attente et la contribution par formation. Il génère des observations sur les formations qui convertissent le mieux ou les étapes qui produisent des abandons.

### 6.10 Business Strategy Agent
Combine les objections des prospects et les indicateurs financiers pour proposer des actions : clarifier les prérequis, revoir les créneaux, mettre en avant les projets pratiques, étudier le positionnement tarifaire ou améliorer le suivi des prospects.

## 7. Architecture technique

```mermaid
flowchart TD
  A[Prospect / apprenant] --> UI[Client Portal]
  O[Owner / gestionnaire] --> DASH[Owner Console]
  UI --> ORCH[Python Training Center Orchestrator]
  ORCH --> SALES[Voice Sales Agent]
  ORCH --> CI[Customer Intelligence Agent]
  ORCH --> NLP[Advanced Customer AI]
  ORCH --> REC[Offer Recommendation Agent]
  ORCH --> FRAUD[ML Fraud Detection Agent]
  FRAUD --> SEC[Security Adapter / moteur externe]
  SEC -->|allow| HUMAN[Validation Owner]
  SEC -->|review| HOLD[Mise en attente]
  SEC -->|block| STOP[Blocage]
  HUMAN --> PAY[Payment Agent / simulateur local]
  PAY --> KPI[Financial Data Analyst]
  KPI --> FI[Financial Intelligence Agent]
  CI --> STRAT[Business Strategy Agent]
  FI --> STRAT
  STRAT --> DASH
  ORCH --> DB[(SQLite + journal d'événements)]
  PAY --> DB
  KPI --> DB
  DASH --> DB
```

### Composants
- **Frontend :** Streamlit, pages Client Portal et Owner Console.
- **Orchestration :** classe Python `TrainingCenterOrchestrator` (alias historique conservé pour les imports de l'application).
- **Agents :** modules Python indépendants dans `agents/`.
- **Données :** SQLite, tables interactions, événements agents et demandes de paiement.
- **ML/NLP :** Scikit-learn, TF-IDF, Logistic Regression, Random Forest.
- **Analyse :** Pandas et NumPy.
- **Visualisation :** Plotly.
- **Voix :** SpeechRecognition et gTTS lorsque les dépendances et périphériques sont disponibles.
- **Tests :** unittest.

## 8. Orchestration de bout en bout

1. Le prospect choisit une formation ou décrit son projet.
2. Le conseiller pédagogique récupère les informations du catalogue.
3. Customer Intelligence analyse le besoin, les motivations et les objections.
4. Advanced Customer AI classe le message et identifie ses thèmes.
5. Offer Recommendation classe les formations pertinentes.
6. Le prospect choisit librement et confirme une demande d'inscription de démonstration.
7. ML Fraud Detection calcule le score de risque.
8. Le Security Adapter examine le contexte et retourne une décision.
9. `block` bloque la demande ; `review` la met en attente ; `allow` permet de solliciter le Owner.
10. Le Owner valide explicitement la demande autorisée.
11. Payment Agent appelle le simulateur local.
12. Financial Data Analyst et Financial Intelligence actualisent les indicateurs.
13. Business Strategy produit des recommandations pour le responsable.
14. Les événements sont enregistrés dans le journal pour assurer la traçabilité.

**Invariant de sécurité :** aucun paiement simulé exécutable ne doit être créé lorsque le contrôle ne retourne pas `allow`. Même après `allow`, la validation humaine est obligatoire. Une erreur ou une réponse invalide du module de sécurité entraîne une mise en attente (fail closed).

## 9. Parcours d'utilisation et cas de démonstration

### Scénario conseillé pour le jury
Un prospect indique : « Je connais un peu Python et je veux me spécialiser en intelligence artificielle, mais je ne sais pas si mon niveau est suffisant et le tarif m'inquiète. »

Le système doit :
1. identifier le domaine IA/ML ;
2. détecter l'objection prix et le besoin de clarification sur le niveau ;
3. présenter les objectifs, la durée et les prérequis documentés ;
4. recommander le parcours IA/ML ou proposer une formation Python préalable si le catalogue et le niveau le justifient ;
5. enregistrer l'intérêt ;
6. si le prospect demande une inscription fictive, déclencher le scoring et le contrôle sécurité ;
7. attendre l'autorisation sécurité puis la validation Owner ;
8. simuler le règlement ;
9. mettre à jour les KPI et les insights du centre.

### Cas de test sécurité
- Cas A : `allow` + validation Owner → simulation possible.
- Cas B : `review` → aucune simulation ; demande en attente.
- Cas C : `block` → demande bloquée.
- Cas D : module externe indisponible ou réponse invalide → mise en attente.
- Cas E : risque ML élevé alors que l'adaptateur répond `allow` → dégradation en `review` pour revue complémentaire.

## 10. Dashboard et indicateurs

### Owner Console
- Overview : interactions, prospects intéressés, inscriptions réglées, revenu simulé, conversion et alertes.
- Gestion des apprenants : profils, historique, objections et intérêts.
- Inscriptions & paiements : demandes, statuts, validation humaine et journal d'événements.
- Training Business Intelligence & ML : tendances, activité et prévisions de démonstration.
- Training Financial Intelligence : revenu simulé, ticket moyen, taux de réussite/échec, demandes en attente et comparaison par formation.
- Enrollment Risk & Fraud : scores, niveaux et signaux de risque.
- Learner & Operations Insights : sentiments, thèmes, objections et recommandations.

### Client Portal
- Conseiller IA.
- Formations recommandées.
- Catalogue & inscriptions.

### KPI principaux
- Nombre de prospects et d'interactions.
- Nombre et part de prospects intéressés.
- Taux de conversion (inscriptions réglées / interactions selon la définition du dashboard).
- Nombre de demandes réussies, échouées, en attente ou bloquées.
- Revenu simulé total et revenu par formation.
- Ticket moyen des règlements simulés réussis.
- Distribution des sentiments et objections.
- Alertes et décisions sécurité.

## 11. Sécurité, confidentialité et limites

- Utiliser exclusivement des noms, messages et transactions fictifs dans la démonstration.
- Ne jamais demander ni stocker numéro de carte, CVV, PIN, mot de passe ou identifiant bancaire.
- Garder les secrets API dans des variables d'environnement, jamais dans le dépôt.
- Appliquer le principe de moindre privilège lors de la future mise en production.
- Ajouter une authentification et une autorisation backend réelles avant toute utilisation multi-utilisateur.
- Journaliser les actions sensibles et limiter l'accès aux données personnelles.
- Traiter les messages utilisateurs comme des données non fiables, jamais comme des instructions système.
- Faire valider les décisions sensibles par un humain.
- Présenter les scores ML comme des signaux d'aide à la revue, pas comme des preuves.

## 12. Technologies et outils

| Outil / technologie | Rôle dans le projet |
|---|---|
| Python | Langage principal et orchestration |
| Streamlit | Interface web interactive |
| Scikit-learn | Modèles ML et NLP |
| Random Forest | Score expérimental de risque |
| TF-IDF | Vectorisation des messages |
| Logistic Regression | Classification de sentiment |
| Pandas / NumPy | Préparation et analyse de données |
| Plotly | Graphiques du dashboard |
| SQLite | Persistance locale des données de démo |
| SpeechRecognition / gTTS | Entrée et sortie vocales optionnelles |
| Requests | Appels API optionnels |
| unittest | Tests automatisés |
| VS Code / Git / GitHub | Environnement de développement et versionnement recommandés |

## 13. Structure du dépôt

```text
TechAcademy_AI_Squad_V9_Training_Center/
├── app.py
├── orchestrator.py
├── ml_forecasting.py
├── requirements.txt
├── agents/
│   ├── sales.py
│   ├── customer_intelligence.py
│   ├── advanced_customer_ai.py
│   ├── offer_recommendation.py
│   ├── fraud_detection.py
│   ├── security_adapter.py
│   ├── payment.py
│   ├── financial_analyst.py
│   ├── financial_intelligence.py
│   └── business_strategy.py
├── services/
│   ├── database.py
│   ├── demo_data.py
│   └── voice.py
├── tests/
└── docs/
    ├── ARCHITECTURE.md
    ├── REQUIREMENTS_AUDIT.md
    ├── SECURITY_PAYMENT_CONTRACT.md
    ├── V9_TRAINING_CENTER.md
    └── PROJECT_BRIEF_A_TO_Z.md
```

## 14. Installation et lancement

Pré-requis : Python 3.10 ou supérieur recommandé.

Windows PowerShell :

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m streamlit run app.py
```

Au premier lancement, le système crée la base SQLite locale et insère des données synthétiques si la base est vide. Pour réinitialiser la démonstration, arrêter Streamlit puis sauvegarder et renommer/supprimer `data/techacademy_training.db` ; au lancement suivant, les données fictives seront recréées.

## 15. Variables d'environnement optionnelles

- `ENABLE_LLM_ASSISTANT=true` pour activer le mode LLM optionnel.
- `GROQ_API_KEY` pour fournir une clé API Groq si cette intégration est utilisée.
- `GROQ_MODEL` pour préciser le modèle disponible.

Ne jamais publier la clé dans GitHub ou dans la présentation.

## 16. Plan de réalisation recommandé

| Phase | Livrable | Priorité |
|---|---|---|
| 1. Cadrage | Problématique, personas, catalogue réel/fictif | Haute |
| 2. Architecture | Diagramme agents, contrats et flux | Haute |
| 3. Parcours prospect | Conseiller, analyse, recommandations | Haute |
| 4. Paiement démo | Demande, statuts, validation Owner | Haute |
| 5. Sécurité | Adaptateur, règles, tests allow/review/block | Critique |
| 6. ML/NLP | Évaluation des modèles et explication | Haute |
| 7. BI/Finance | KPI et recommandations | Haute |
| 8. Qualité | Tests intégrés, tests UI et scénarios d'erreur | Haute |
| 9. Présentation | Démo chronométrée, architecture, limites | Haute |

## 17. Audit par rapport au cahier des charges du hackathon

Le scénario centre de formation est compatible parce qu'il représente un cas concret de vente d'un service, de qualification d'un prospect, de demande de paiement, d'analyse des résultats et de contrôle de sécurité. Le sujet reste la construction d'une équipe FinTech autonome : le centre de formation est le domaine métier choisi pour la démonstration, et non un remplacement des exigences du hackathon.

| Attente du cahier des charges | Réponse dans V9 | État |
|---|---|---|
| Agent de vente / présentation d'offre | Conseiller pédagogique et catalogue de formations | Implémenté en prototype |
| Intelligence client | Analyse des besoins, motivations et objections | Implémenté, baseline heuristique |
| Agent de paiement | Demande d'inscription et simulateur local | Implémenté en simulation |
| Analyse financière / BI | KPI, revenus simulés, performance par formation | Implémenté |
| Stratégie métier | Recommandations pour le centre | Implémenté |
| Sécurité / fraude | Score ML + adaptateur de sécurité externe | Partiel tant que le moteur collaborateur n'est pas intégré |
| Au moins 3 agents interconnectés | Plusieurs agents partagent le contexte de parcours | Dépassé |
| Données de démonstration | Jeu de données synthétique | Implémenté |
| Paiement sans argent réel | Fournisseur local simulé | Conforme au mode prototype |
| Validation humaine | Contrôle Owner après `allow` | Implémenté dans le flux de démo |
| Contrôle d'accès réel | Sélecteur Owner/Client uniquement | À renforcer |
| Démonstration intégrée | Dépend du branchement du vrai moteur sécurité | À finaliser |

**Conclusion :** le projet est aligné sur le scénario et les fonctions centrales du cahier des charges, mais il ne faut pas annoncer une conformité complète tant que le module de sécurité du coéquipier, les contrôles d'accès et la démonstration intégrée ne sont pas validés.

## 18. Limites techniques à annoncer honnêtement

- Le classifieur NLP est entraîné sur un petit corpus artificiel ; il doit être évalué sur un jeu annoté plus large.
- Le Random Forest est entraîné sur des événements synthétiques générés par règles ; ses performances ne prouvent pas une capacité réelle à détecter la fraude.
- Le moteur de recommandation est un classement par mots-clés et métadonnées, non un système adaptatif entraîné sur les historiques d'apprenants.
- La prévision ML est une démonstration et ne doit pas être présentée comme une prévision financière certifiée.
- Le module sécurité externe reste à intégrer ; son absence entraîne une mise en attente et non une autorisation.
- L'authentification et les rôles ne sont pas encore sécurisés côté serveur.
- Le fournisseur de paiement est un simulateur local.

## 19. Améliorations futures

1. Connecter le moteur antifraude réel du coéquipier et formaliser son API.
2. Ajouter une authentification robuste, des rôles et une journalisation d'audit.
3. Remplacer le corpus NLP synthétique par un jeu de données annoté et mesurer précision, rappel et F1-score.
4. Ajouter une évaluation hors échantillon, une matrice de confusion et un suivi de dérive pour le modèle de risque.
5. Ajouter des prérequis explicites et un test de positionnement pédagogique.
6. Ajouter un calendrier de sessions, la disponibilité des places et des listes d'attente.
7. Ajouter un CRM léger pour le suivi des prospects.
8. Migrer SQLite vers PostgreSQL et séparer backend/API et frontend si le prototype évolue.
9. Conteneuriser avec Docker pour faciliter le déploiement.
10. Ajouter une intégration Sandbox uniquement si elle est autorisée et utile à la démonstration.

## 20. Proposition de valeur et différenciation

La valeur distinctive de TechAcademy AI Squad est la collaboration de plusieurs intelligences autour d'un même parcours :
- **Learner Intelligence :** comprendre le besoin et le niveau de l'apprenant.
- **Learning Recommendation Intelligence :** recommander le bon parcours et expliquer pourquoi.
- **Fraud & Security Intelligence :** contrôler les demandes d'inscription et de règlement.
- **Training Financial Intelligence :** mesurer les conversions et les revenus par formation.
- **Business Strategy Intelligence :** transformer ces résultats en actions pour le centre.

Le projet se différencie d'un chatbot simple parce que les agents échangent des résultats structurés, déclenchent des étapes contrôlées, enregistrent les événements et alimentent une console de pilotage.

## 21. Pitch de présentation (60 secondes)

« TechAcademy AI Squad est une plateforme multi-agents conçue pour un centre de formation spécialisé dans les métiers de l'informatique. Elle accompagne un prospect depuis l'expression de son besoin jusqu'à sa demande d'inscription. Nos agents analysent son profil et ses objections, recommandent les formations les plus adaptées, évaluent le risque d'une demande grâce au Machine Learning et déclenchent un contrôle de sécurité avec validation humaine. Après la simulation du règlement, les agents financiers analysent les conversions et les revenus par formation, puis l'agent Business Strategy propose des améliorations au centre. Notre objectif est de démontrer comment une équipe d'agents IA peut relier expérience apprenant, sécurité et intelligence décisionnelle dans un parcours traçable. »

## 22. Glossaire

- **Agent IA :** composant logiciel spécialisé dans une tâche et capable de produire un résultat structuré.
- **Orchestrateur :** composant qui coordonne les agents et les étapes du workflow.
- **NLP :** traitement automatique du langage naturel.
- **TF-IDF :** méthode de représentation numérique des textes.
- **Logistic Regression :** algorithme de classification supervisée.
- **Random Forest :** ensemble d'arbres de décision utilisé ici pour le scoring expérimental du risque.
- **KPI :** indicateur clé de performance.
- **BI :** Business Intelligence, analyse et visualisation pour la décision.
- **Human-in-the-loop :** validation humaine intégrée à un processus automatisé.
- **Fail closed :** en cas d'erreur de sécurité, le système refuse l'autorisation et place la demande en attente.
- **Sandbox :** environnement de test isolé d'un fournisseur ; aucun environnement bancaire réel n'est utilisé ici.

---

**Statut du document :** dossier de conception et de présentation du prototype V9. Les caractéristiques du catalogue et les tarifs sont fictifs et doivent être remplacés par les données validées du centre choisi avant une démonstration publique.
