# Répartition des responsabilités — V9

## Implémenté dans le prototype
- Client Portal et Owner Console pour le centre de formation.
- Conseiller pédagogique ancré dans le catalogue de formations.
- Customer Intelligence : intérêts, motivations, objections et sentiment heuristique.
- Advanced Customer AI : TF-IDF + Logistic Regression sur corpus synthétique.
- Offer Recommendation Agent : classement explicable des formations.
- ML Fraud Detection : score expérimental Random Forest sur données synthétiques.
- Financial Data Analyst et Financial Intelligence pour KPI et revenus simulés.
- Business Strategy Agent pour recommandations au centre.
- Orchestrateur Python, SQLite et journal d'événements.
- Payment Agent avec simulateur local, contrôle sécurité et validation Owner.

## À fournir / intégrer par le collaborateur sécurité
- Moteur réel de détection et règles de sécurité.
- Décisions allow / review / block avec explications.
- Validation des entrées, contrôles de permissions et gestion des alertes.
- Tests de robustesse et protection contre les tentatives de prompt injection.

## Limites restantes
- Adaptateur de sécurité par défaut : review en attente d'intégration.
- Pas de paiement réel ni de passerelle bancaire Sandbox.
- Authentification et RBAC de production non implémentés.
- Modèles ML/NLP expérimentaux sur données synthétiques.
