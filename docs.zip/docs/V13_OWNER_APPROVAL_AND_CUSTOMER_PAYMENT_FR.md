# V13 — Validation Owner et paiement client

## Workflow livré
1. Une demande est créée ; les informations de montant et de référence client sont conservées dans le registre privé `data/private_payment_ledger.db`. La table Owner `payment_requests` ne contient pas de montant, numéro de carte, CVV, PIN ou identifiant de transaction.
2. Le contrôle local de sécurité utilise le résultat ML et le filtre Prompt Injection : faible = allow, moyen = review, élevé ou injection = block.
3. Une demande `review` exige une revue humaine motivée. Une demande `block` ne peut pas être approuvée.
4. Après contrôle favorable, l'Owner peut approuver ou refuser. Le refus exige un motif.
5. L'approbation Owner ne débite rien : elle passe à `approved_pending_customer_payment`.
6. L'apprenant retrouve sa demande avec son identifiant et confirme le paiement simulé.
7. Le résultat et le statut sont enregistrés ; la référence de transaction de démonstration reste dans le registre privé, pas dans la base Owner.

## Important — limites
- Le fournisseur de paiement est `DemoPaymentProvider` local : aucun paiement réel ni passerelle bancaire n'est connecté.
- L'écran client ne demande aucune donnée bancaire. Pour un vrai paiement, intégrer un prestataire conforme via une page hébergée/tokenisation (ex. checkout hébergé) ; ne jamais collecter carte/CVV/PIN dans cette application.
- Le module du collaborateur est toujours un sous-projet séparé ; le fallback de sécurité local V13 est utilisé par l'application Streamlit jusqu'à la connexion API du module externe.
- Le fallback local est une politique de démonstration, pas un service antifraude de production.
- La séparation des fichiers SQLite n'est pas une isolation de sécurité production. Prévoir chiffrement, contrôle d'accès OS/DB, secrets manager, journalisation et audit avant déploiement.

## Tests
- Application : 30 tests `unittest` réussis.
- Backend collaborateur : 73 tests `pytest` réussis.
