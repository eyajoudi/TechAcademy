# TechAcademy AI Squad V10 — Upgrade & audit

## Goal
V10 improves the integration of the training-enrollment journey: actual risk inputs from the enrollment form feed the ML model; the model assessment and prompt-injection screening are passed to the external security adapter; payment remains blocked until a security `allow` and a separate Owner approval.

## V10 changes
1. **Risk inputs connected to enrollment**: the enrollment form collects the transaction velocity in 10 minutes, failed attempts in 24 hours, new-device flag, unusual distance, and requester/enrollment mismatch. The operation hour is captured at submission. These values are passed to `TrainingCenterOrchestrator.run(..., risk_features=...)` and then to `FraudDetectionAgent.assess`.
2. **ML explainability**: risk score, level, threshold-based signals, exact model input features, and global Random Forest feature importances are displayed. Global feature importance is not a per-decision causal explanation.
3. **Security handoff**: the external adapter receives the transaction context, ML assessment, and prompt-injection screening result. Invalid/unavailable responses fail closed to `review`. A high ML risk or flagged injection downgrades an external `allow` to `review`.
4. **Payment safety**: no simulated payment is executed before external security `allow` and explicit Owner approval. `review`, `block`, invalid output, and exceptions do not execute payment.
5. **Role login / RBAC for the demo UI**: Owner and Learner login sessions have separate page allowlists. Demo credentials are `owner / ChangeMe-Owner-V10` and `learner / ChangeMe-Learner-V10`. Override with environment variables `TECHACADEMY_OWNER_PASSWORD` and `TECHACADEMY_LEARNER_PASSWORD`.
6. **Prompt-injection screening**: a lightweight input guard flags common instruction-override, hidden-prompt extraction, security-bypass, and privilege-escalation phrases. Flagged text remains untrusted data and requires review.
7. **Financial Intelligence**: adds average simulated revenue per interaction and best observed conversion insight by training offer.

## Important limitations
- `ExternalSecurityAdapter` remains a placeholder returning `review`. The teammate-owned security engine is **not integrated** until its implementation replaces or is injected into this adapter.
- Demo credentials and Streamlit session role checks are suitable for a local hackathon prototype only. This is not production-grade identity management or backend authorization. Use a proper identity provider, password hashing, HTTPS, secure secrets, and server-side authorization before deployment.
- Fraud model training data is synthetic and rule-generated. It is not suitable for real fraud decisions. Validate on representative, consented, labeled data and report precision, recall, F1, ROC-AUC, calibration, and false-positive rates before any real use.
- Prompt-injection screening is a lightweight heuristic, not a complete LLM security solution. It must be combined with tool permissions, strict schemas, output validation, least privilege, and human review.
- Payments are local simulations only. No real bank, card, CVV, PIN, or payment credentials are used.
- Streamlit UI visual testing must be performed on the team's Windows environment.

## Cahier des charges alignment
| Requirement | V10 status |
|---|---|
| Sales / voice agent | Present; voice is not a real-time voice agent |
| Customer intelligence | Present; NLP remains a prototype |
| Payment agent | Present; local simulator only |
| Financial analyst | Present |
| Business strategy | Present |
| Security & fraud | Partial: ML and adapter contract present; teammate's actual engine pending |
| At least 3 interconnected agents | Present |
| Dashboard / BI | Present |
| Human approval | Present after security allow |
| Synthetic/demo data | Present |
| Prompt injection defense | Partial heuristic screening and tests |
| Authentication / RBAC | Demo UI role separation; not production grade |
| Sandbox payment API | Not implemented; not mandatory for a simulated prototype unless specifically required by organizers |

## Test command
```bash
python -m compileall -q .
python -m unittest discover -s tests -v
```
