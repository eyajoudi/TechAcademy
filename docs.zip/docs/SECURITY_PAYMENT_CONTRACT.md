# Contrat d'intégration — inscription et règlement d'une formation

## Parcours
1. Le prospect soumet une demande d'inscription fictive à une formation.
2. L'orchestrateur construit un contexte avec référence fictive, formation, montant, confirmation et `purpose=training_course_enrollment_demo`.
3. ML Fraud Detection produit un score et des signaux explicatifs.
4. L'adaptateur transmet le contexte au moteur de sécurité externe.
5. Le moteur retourne un dictionnaire avec `decision` (`allow`, `review` ou `block`), `risk_level`, `reasons` et éventuellement `requires_human_approval`.
6. `review`, `block`, exception ou réponse invalide empêchent l'exécution du paiement.
7. Si la décision est `allow`, le propriétaire doit encore approuver explicitement la demande.
8. Après ces deux contrôles, le Payment Agent appelle uniquement le fournisseur local de simulation.

## Interface attendue
Le coéquipier peut implémenter `review(context)` dans `agents/security_adapter.py` ou fournir un objet compatible à `TrainingCenterOrchestrator(..., security_adapter=adapter)`.

Exemple de réponse :

```python
{
    "decision": "review",
    "risk_level": "medium",
    "reasons": ["Demande nécessitant une vérification"],
    "requires_human_approval": True
}
```

## Règles non négociables
- Le modèle ML ne peut pas autoriser seul un règlement.
- Un risque ML élevé dégrade une réponse `allow` en `review`.
- Le système échoue en mode fermé : panne ou réponse invalide => `review`.
- Aucune donnée bancaire réelle n'est collectée.
- Le fournisseur actuel est un simulateur local.
