# V5 — Product and technical improvements

## 1. Client experience
- Offer cards are retained.
- Client can describe their goal before choosing.
- Offer Recommendation Agent ranks catalogue items and explains each match.
- The client always chooses; the system does not enroll or charge automatically.

## 2. Customer Intelligence
- Lexical sentiment with whole-token matching.
- Negation and intensity handling.
- Mixed sentiment label.
- Purchase, information and clarification intent.
- Objection, motivation and urgency extraction.
- Evidence and next-best-action explanation.

## 3. Owner Console
- New Customer Insights & Offer Performance page.
- Sentiment distribution and follow-up list.
- Offer-level interaction, interest and successful demo payment comparison.
- Objection analysis and CSV follow-up export.
- Agent and workflow history include offer recommendations.

## 4. Evaluation and limitations
The current sentiment component is an interpretable baseline. It is not a clinically meaningful emotion detector and does not understand every dialect or sarcasm. Its numeric scores are heuristic. Before production, create a consented, human-labelled test set and evaluate macro-F1, per-class precision/recall, confusion matrix and calibration. Include French, English and Tunisian Derja if those are supported languages.

The recommendation component uses catalogue-content matching. It must be evaluated against historical, consented interactions using Precision@K, Recall@K or NDCG@K. A score is a ranking signal, not a purchase probability.

## 5. Professional roadmap
- Authentication, authorization and separate deployment for Owner/Client.
- API boundary around orchestrator.
- Observability: structured logs, error states, latency, run correlation IDs.
- Privacy: consent, purpose limitation, retention and deletion workflow.
- Human feedback: sentiment correction and recommendation accepted/rejected.
- Integrate external cybersecurity and then the payment provider sandbox with explicit approval.
