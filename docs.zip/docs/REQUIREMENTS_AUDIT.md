# Audit du cahier des charges — TechAcademy AI Squad V9

## Conclusion
Le scénario d'un centre de formation informatique est compatible avec le hackathon : il s'agit d'un service vendu à des prospects, avec présentation d'offre, analyse client, demande de paiement simulée, analyse des résultats, recommandations et contrôle de sécurité. Le projet conserve les quatre piliers du challenge : Agentic AI, FinTech, Data & BI et Cybersecurity.

| Attente | Implémentation V9 | État |
|---|---|---|
| Voice Sales Agent | Conseiller pédagogique, catalogue, questions et réponses | Prototype implémenté |
| Customer Intelligence | Besoins, motivations, objections et signaux d'intérêt | Baseline heuristique |
| Payment Agent | Demande d'inscription et fournisseur local simulé | Implémenté en simulation |
| Financial Data Analyst | KPI de conversion, revenus simulés et statuts | Implémenté |
| Business Strategy Agent | Recommandations fondées sur objections et indicateurs | Implémenté |
| Security & Fraud Detection | Random Forest de risque + adaptateur externe | Partiel, intégration réelle requise |
| 3 agents interconnectés minimum | Plusieurs agents coordonnés par orchestrateur | Dépassé |
| Données fictives / anonymisées | Jeu de démonstration synthétique | Implémenté |
| Paiement sans argent réel | Simulateur local | Implémenté |
| Human-in-the-loop | Validation Owner après décision `allow` | Implémenté |
| Least privilege / RBAC | Séparation d'interface Owner/Client seulement | À renforcer |
| Protection contre prompt injection | Instructions de prudence, pas de filtre/évaluation robuste complète | Partiel |
| Démo end-to-end | Parcours possible avec adaptateur de test `allow` | À finaliser avec le moteur réel du coéquipier |

## Éléments à finaliser avant la présentation
1. Intégrer le moteur de sécurité du coéquipier via `agents/security_adapter.py`.
2. Tester les scénarios `allow`, `review`, `block`, erreur, réponse invalide et score ML élevé.
3. Mettre en place une vraie authentification et des permissions côté backend si le temps le permet.
4. Vérifier l'interface Streamlit sur la machine de démonstration.
5. Répéter une démonstration complète avec données fictives.

## Limites à annoncer
- Le modèle Random Forest est entraîné sur des données synthétiques générées par règles : il démontre un mécanisme de scoring, mais n'est pas un détecteur de fraude validé.
- Le NLP est entraîné sur un petit corpus artificiel et doit être évalué sur des messages annotés.
- La recommandation est fondée sur mots-clés et métadonnées de formation.
- Les règlements sont simulés ; aucun paiement bancaire réel.
- L'adaptateur de sécurité par défaut renvoie `review` tant que le moteur externe n'est pas intégré.
