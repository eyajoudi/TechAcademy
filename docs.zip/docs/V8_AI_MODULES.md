# V8 — Modules IA avancés

## 1. ML Fraud Detection Agent
- Modèle : RandomForestClassifier (scikit-learn).
- Variables de démonstration : montant, heure, vélocité, tentatives échouées, nouvel appareil, distance géographique, incohérence marchand.
- Sorties : score 0–100, niveau de risque, signaux explicatifs.
- Entraînement : événements synthétiques générés localement. Ce n'est pas un modèle bancaire validé.
- Règle d'orchestration : un score haut transforme une décision externe `allow` en `review`; le ML ne peut jamais autoriser un paiement.

## 2. Advanced Customer AI
- Pipeline hybride : Customer Intelligence lexical + TF-IDF n-grams + Logistic Regression.
- Classes : positive, negative, neutral, mixed.
- Extraction de thèmes : prix, sécurité, paiement, wallet, facturation récurrente.
- Les probabilités sont indicatives car le corpus est petit et synthétique. Pour la production, collecter des données autorisées, annotées et représentatives, évaluer précision/rappel/F1, biais et dérive.

## 3. Financial Intelligence Agent
- KPI : revenu simulé, ticket moyen, taux de succès, taux d'échec, taux d'attente.
- Segmentation par offre : volume, transactions réussies, revenu, conversion.
- Insights explicables : alertes sur échecs/attentes et offre contributrice.
- Les métriques sont calculées sur les enregistrements du prototype; elles ne remplacent pas la comptabilité.

## Pipeline d'une transaction
1. Le client confirme explicitement une demande.
2. Advanced Customer AI enrichit le profil conversationnel (en amont du parcours).
3. ML Fraud Detection calcule un score de risque sur les attributs disponibles.
4. Le module Security du collaborateur examine le contexte et le score ML.
5. `block` bloque; `review` met en attente; `allow` n'est qu'une pré-autorisation.
6. Le propriétaire doit encore valider manuellement.
7. Le simulateur local produit un statut fictif.
8. Financial Data Analyst et Financial Intelligence calculent les KPI et les insights.

## Limites connues
- Les attributs transactionnels avancés sont simulés par défaut dans le parcours standard. Le formulaire Risk & Fraud Intelligence permet de tester les variables.
- Pas de données réelles, de paiement réel, ni de décision de fraude en production.
- Le module sécurité externe du collaborateur reste le contrôle de référence et doit être intégré/testé conjointement.
