# V12 — Améliorations du conseiller IA, des recommandations et de la sécurité

## 1. Conseiller IA
- Réponses contextualisées à l'historique récent ; les réponses courtes comme « oui » sont interprétées comme une suite de la question précédente.
- Réponse dédiée aux demandes RAG : définition, usage, et distinction claire entre notion générale et contenu réellement confirmé dans le catalogue.
- Prompt Groq renforcé : réponses concises, ancrées dans le catalogue, pas de tarifs/certifications/prérequis inventés, pas de répétition de salutation.
- Repli local contextuel si Groq est absent ou indisponible. Le mode actif est visible dans les résultats.
- Pour activer Groq : définir ENABLE_LLM_ASSISTANT=true et GROQ_API_KEY dans l'environnement du terminal avant de lancer Streamlit.

## 2. Recommandation de formations
- Remplacement du score essentiellement lexical par un score explicable multi-critères : domaine, compétences recherchées, niveau, objectif professionnel et budget.
- Alias métier ajoutés (ex. RAG, Retrieval-Augmented Generation, LLM, Docker, Kubernetes, SOC, AWS/Azure).
- Les formations sans correspondance suffisante ne sont plus présentées comme de bonnes recommandations.
- Le système pose des questions de clarification lorsque le besoin est trop vague.
- Le score est une mesure de correspondance aux critères exprimés, pas une probabilité de réussite.

## 3. Sécurité
- Filtrage Prompt Injection élargi à plusieurs formulations françaises et tentatives d'extraction de secrets.
- Le backend du collaborateur exige désormais une validation humaine avant toute exécution de paiement simulé, même si le contrôle automatique ne détecte aucun risque.
- Un blocage de sécurité reste bloquant ; l'approbation humaine ne contourne pas le blocage.

## 4. Tests
- Application Streamlit : 27 tests unittest réussis.
- Backend collaborateur : 73 tests pytest réussis.
- Ces tests sont exécutés séparément. Le backend du collaborateur reste dans son sous-dossier et n'est pas encore connecté à l'orchestrateur Streamlit par une API. Ne pas présenter le bundle comme une intégration end-to-end des deux applications.
- Les paiements sont simulés uniquement ; aucune donnée bancaire réelle ne doit être utilisée.
