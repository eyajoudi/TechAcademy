from app.agents.sales.agent import SalesAgent
from app.agents.sales.models import InterestLevel, SalesIntent
from app.db import EventStore
from app.llm.fake_client import FakeLLMClient


def test_handle_turn_logs_event_and_returns_structured_output():
    with EventStore() as store:
        agent = SalesAgent(store, FakeLLMClient())

        result = agent.handle_turn("lead_1", "Hi there!")

        assert result.detected_intent == SalesIntent.GREETING
        assert result.interest_level == InterestLevel.LOW

        events = store.get_events(agent="sales_agent", type_="sales_turn")
        assert len(events) == 1
        assert events[0].payload["lead_id"] == "lead_1"
        assert events[0].payload["customer_message"] == "Hi there!"
        assert events[0].status == "low"


def test_handle_turn_captures_objection():
    with EventStore() as store:
        agent = SalesAgent(store, FakeLLMClient())

        result = agent.handle_turn("lead_1", "What's the price?")

        assert result.objection == "price"
        events = store.get_events(agent="sales_agent", type_="sales_turn")
        assert events[0].payload["objection"] == "price"


def test_multiple_turns_accumulate_for_same_lead():
    with EventStore() as store:
        agent = SalesAgent(store, FakeLLMClient())

        agent.handle_turn("lead_1", "Hello")
        agent.handle_turn("lead_1", "How much does it cost?")
        agent.handle_turn("lead_1", "Ok sign me up!")

        events = store.get_events(agent="sales_agent", type_="sales_turn")
        assert len(events) == 3
        assert [e.payload["detected_intent"] for e in events] == [
            "greeting",
            "pricing_question",
            "ready_to_enroll",
        ]
