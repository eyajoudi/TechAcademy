from app.agents.customer_intelligence.agent import CustomerIntelligenceAgent
from app.db import EventStore
from app.llm.fake_client import FakeLLMClient


def test_analyze_transcript_logs_event_and_returns_insights():
    with EventStore() as store:
        agent = CustomerIntelligenceAgent(store, FakeLLMClient())

        transcript = ["Hi", "What's the price? Seems expensive.", "I'm worried I don't have time."]
        insights = agent.analyze_transcript("lead_1", transcript)

        assert "price" in insights.objections
        assert "time_commitment" in insights.objections
        assert insights.intent_score < 0.5

        events = store.get_events(agent="customer_intelligence_agent", type_="customer_insights")
        assert len(events) == 1
        assert events[0].payload["lead_id"] == "lead_1"
        assert events[0].payload["objections"] == insights.objections
        assert events[0].status == "completed"


def test_analyze_transcript_detects_high_intent():
    with EventStore() as store:
        agent = CustomerIntelligenceAgent(store, FakeLLMClient())

        transcript = ["Hi", "This sounds great, sign me up!"]
        insights = agent.analyze_transcript("lead_2", transcript)

        assert insights.intent_score > 0.5
        assert "high_interest" in insights.satisfaction_signals
