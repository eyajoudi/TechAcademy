from app.agents.business_strategy.agent import BusinessStrategyAgent
from app.agents.financial_analyst.models import FinancialReport
from app.db import EventStore
from app.llm.fake_client import FakeLLMClient


def _log_customer_insights(store, lead_id, objections, satisfaction_signals=None, intent_score=0.5):
    store.log_event(
        agent="customer_intelligence_agent",
        type_="customer_insights",
        payload={
            "lead_id": lead_id,
            "needs": [],
            "objections": objections,
            "motivations": [],
            "satisfaction_signals": satisfaction_signals or [],
            "intent_score": intent_score,
        },
        status="completed",
    )


def test_aggregates_customer_insights_across_leads():
    with EventStore() as store:
        agent = BusinessStrategyAgent(store, FakeLLMClient())
        _log_customer_insights(store, "lead_1", objections=["price"], intent_score=0.3)
        _log_customer_insights(store, "lead_2", objections=["price", "time_commitment"], intent_score=0.4)

        insights = agent._aggregate_customer_insights()

        assert insights.leads_analyzed == 2
        assert insights.objections.count("price") == 2
        assert "time_commitment" in insights.objections
        assert abs(insights.average_intent_score - 0.35) < 1e-9


def test_generate_recommendations_flags_price_objection():
    with EventStore() as store:
        agent = BusinessStrategyAgent(store, FakeLLMClient())
        _log_customer_insights(store, "lead_1", objections=["price"], intent_score=0.3)

        report = agent.generate_recommendations(FinancialReport())

        assert "price" in report.top_objections_addressed
        assert any("discount" in r.title.lower() or "payment plan" in r.title.lower() for r in report.recommendations)


def test_generate_recommendations_logs_event():
    with EventStore() as store:
        agent = BusinessStrategyAgent(store, FakeLLMClient())
        _log_customer_insights(store, "lead_1", objections=["price"], intent_score=0.3)

        agent.generate_recommendations(FinancialReport())

        events = store.get_events(agent="business_strategy_agent", type_="recommendations")
        assert len(events) == 1
        assert events[0].status == "completed"
        assert events[0].payload["recommendations"]


def test_security_alerts_trigger_a_review_recommendation():
    with EventStore() as store:
        agent = BusinessStrategyAgent(store, FakeLLMClient())

        report = agent.generate_recommendations(
            FinancialReport(security_alerts_count=2, security_alert_breakdown={"velocity": 2})
        )

        assert any("flagged" in r.title.lower() or "security alert" in r.rationale.lower() for r in report.recommendations)


def test_no_data_falls_back_to_generic_recommendation():
    with EventStore() as store:
        agent = BusinessStrategyAgent(store, FakeLLMClient())

        report = agent.generate_recommendations(FinancialReport())

        assert len(report.recommendations) == 1
        assert report.recommendations[0].priority == "low"
