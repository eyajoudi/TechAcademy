import pytest

from app.agents.payment.agent import PaymentAgent
from app.agents.payment.models import PaymentRequest, PaymentStatus
from app.agents.security.agent import SecurityAgent
from app.db import EventStore


def _make_agents(store: EventStore) -> tuple[PaymentAgent, SecurityAgent]:
    security = SecurityAgent(store)
    payment = PaymentAgent(store, security)
    return payment, security


def test_create_request_logs_pending_event():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=49.0, payment_method_token="tok_visa")

        event_id = payment.create_request(request)
        logged = store.get_event(event_id)

        assert logged.agent == "payment_agent"
        assert logged.type == "payment_request"
        assert logged.status == "pending"
        assert logged.payload["customer_id"] == "cust_1"
        assert logged.payload["amount"] == 49.0


def test_execute_success_token():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=49.0, payment_method_token="tok_visa")
        event_id = payment.create_request(request)

        result = payment.execute(event_id, request)

        assert result.status == PaymentStatus.SUCCEEDED
        assert result.reason is None
        assert store.get_event(event_id).status == "succeeded"


def test_execute_decline_token():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(
            customer_id="cust_1", amount=49.0, payment_method_token="tok_decline_generic"
        )
        event_id = payment.create_request(request)

        result = payment.execute(event_id, request)

        assert result.status == PaymentStatus.DECLINED
        assert result.reason == "generic_decline"


def test_mark_pending_approval_updates_store_and_result():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=999.0)
        event_id = payment.create_request(request)

        result = payment.mark_pending_approval(
            event_id, alerts=["amount exceeds threshold"], risk_score=0.5
        )

        assert result.status == PaymentStatus.PENDING_APPROVAL
        assert "amount exceeds threshold" in result.reason
        logged = store.get_event(event_id)
        assert logged.status == "pending_approval"
        assert logged.payload["risk_score"] == 0.5


def test_mark_blocked_sets_blocked_status_directly_from_pending():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=25.0)
        event_id = payment.create_request(request)

        result = payment.mark_blocked(event_id, alerts=["possible prompt injection in memo: [...]"])

        assert result.status == PaymentStatus.BLOCKED
        assert "injection" in result.reason
        logged = store.get_event(event_id)
        assert logged.status == "blocked"
        assert logged.payload["security_alerts"] == ["possible prompt injection in memo: [...]"]


def test_resolve_denied_requires_pending_approval_status():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=10.0)
        event_id = payment.create_request(request)
        payment.execute(event_id, request)  # now succeeded, not pending_approval

        with pytest.raises(ValueError):
            payment.resolve_denied(event_id, reason="too late")


def test_resolve_denied_marks_declined_with_reason():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=999.0)
        event_id = payment.create_request(request)
        payment.mark_pending_approval(event_id, alerts=["high amount"], risk_score=0.5)

        result = payment.resolve_denied(event_id, reason="looks fraudulent")

        assert result.status == PaymentStatus.DECLINED
        assert "fraudulent" in result.reason


def test_request_from_event_rebuilds_request():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        original = PaymentRequest(
            customer_id="cust_1", amount=999.0, currency="EUR", payment_method_token="tok_visa"
        )
        event_id = payment.create_request(original)
        payment.mark_pending_approval(event_id, alerts=["high amount"], risk_score=0.5)

        rebuilt = payment.request_from_event(event_id)

        assert rebuilt.customer_id == "cust_1"
        assert rebuilt.amount == 999.0
        assert rebuilt.currency == "EUR"
        assert rebuilt.payment_method_token == "tok_visa"


def test_request_from_event_rejects_non_pending_events():
    with EventStore() as store:
        payment, _ = _make_agents(store)
        request = PaymentRequest(customer_id="cust_1", amount=10.0)
        event_id = payment.create_request(request)
        payment.execute(event_id, request)  # resolved already, not pending_approval

        with pytest.raises(ValueError):
            payment.request_from_event(event_id)
