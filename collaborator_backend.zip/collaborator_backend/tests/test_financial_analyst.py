from app.agents.financial_analyst.agent import FinancialDataAnalystAgent
from app.db import EventStore


def test_empty_store_yields_zeroed_report():
    with EventStore() as store:
        report = FinancialDataAnalystAgent(store).generate_report()

        assert report.payments_succeeded == 0
        assert report.payments_declined == 0
        assert report.payments_pending_approval == 0
        assert report.total_payment_attempts == 0
        assert report.revenue_by_currency == {}
        assert report.security_alerts_count == 0
        assert report.conversion_rate is None


def test_counts_and_revenue_from_resolved_payments():
    with EventStore() as store:
        succeeded_1 = store.log_event(
            "payment_agent", "payment_request", {"customer_id": "c1", "amount": 100.0, "currency": "USD"}, "pending"
        )
        store.update_event_status(succeeded_1, "succeeded", {"reason": None})

        succeeded_2 = store.log_event(
            "payment_agent", "payment_request", {"customer_id": "c2", "amount": 50.0, "currency": "EUR"}, "pending"
        )
        store.update_event_status(succeeded_2, "succeeded", {"reason": None})

        declined = store.log_event(
            "payment_agent", "payment_request", {"customer_id": "c3", "amount": 20.0, "currency": "USD"}, "pending"
        )
        store.update_event_status(declined, "declined", {"reason": "generic_decline"})

        pending = store.log_event(
            "payment_agent", "payment_request", {"customer_id": "c4", "amount": 999.0, "currency": "USD"}, "pending"
        )
        store.update_event_status(pending, "pending_approval", {"security_alerts": ["x"]})

        report = FinancialDataAnalystAgent(store).generate_report()

        assert report.payments_succeeded == 2
        assert report.payments_declined == 1
        assert report.payments_pending_approval == 1
        assert report.total_payment_attempts == 4
        assert report.revenue_by_currency == {"USD": 100.0, "EUR": 50.0}


def test_security_alert_breakdown_by_category():
    with EventStore() as store:
        store.log_event(
            "security_agent",
            "payment_screen",
            {"alerts": ["amount 999.0 meets or exceeds auto-approve threshold"]},
            "flagged",
        )
        store.log_event(
            "security_agent",
            "payment_screen",
            {"alerts": ["velocity check failed for customer 'c4'"]},
            "flagged",
        )
        store.log_event(
            "security_agent",
            "payment_screen",
            {"alerts": [
                "possible prompt injection in memo: ['instruction_override']",
                "amount 10.0 meets or exceeds auto-approve threshold",
            ]},
            "flagged",
        )
        store.log_event("security_agent", "payment_screen", {"alerts": []}, "clear")

        report = FinancialDataAnalystAgent(store).generate_report()

        assert report.security_alerts_count == 3
        assert report.security_alert_breakdown["amount_threshold"] == 2
        assert report.security_alert_breakdown["velocity"] == 1
        assert report.security_alert_breakdown["prompt_injection"] == 1
        assert report.security_alert_breakdown["duplicate_payment"] == 0


def test_blocked_screens_are_counted_as_alerts_separately_from_flagged():
    with EventStore() as store:
        store.log_event(
            "security_agent", "payment_screen",
            {"alerts": ["amount 999.0 meets or exceeds auto-approve threshold"]}, "flagged",
        )
        store.log_event(
            "security_agent", "payment_screen",
            {"alerts": ["possible prompt injection in memo: ['instruction_override']"]}, "blocked",
        )
        store.log_event("security_agent", "payment_screen", {"alerts": []}, "clear")

        report = FinancialDataAnalystAgent(store).generate_report()

        assert report.security_alerts_count == 2  # flagged + blocked
        assert report.security_blocked_count == 1
        assert report.security_alert_breakdown["prompt_injection"] == 1


def test_human_decision_counts():
    with EventStore() as store:
        store.log_event(
            "security_agent", "human_decision",
            {"decision": "approve", "approver": "a"}, "approved",
        )
        store.log_event(
            "security_agent", "human_decision",
            {"decision": "deny", "approver": "a", "reason": "x"}, "denied",
        )
        store.log_event(
            "security_agent", "human_decision",
            {"decision": "deny", "approver": "b", "reason": "y"}, "denied",
        )

        report = FinancialDataAnalystAgent(store).generate_report()

        assert report.human_decisions_approved == 1
        assert report.human_decisions_denied == 2
