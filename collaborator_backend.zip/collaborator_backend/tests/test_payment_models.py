import pytest
from pydantic import ValidationError

from app.agents.payment.models import PaymentRequest


def test_valid_request_constructs():
    request = PaymentRequest(customer_id="cust_1", amount=100.0)
    assert request.currency == "USD"
    assert request.payment_method_token == "tok_visa"


def test_zero_or_negative_amount_rejected():
    with pytest.raises(ValidationError):
        PaymentRequest(customer_id="cust_1", amount=0)

    with pytest.raises(ValidationError):
        PaymentRequest(customer_id="cust_1", amount=-5)


def test_unsupported_currency_rejected():
    with pytest.raises(ValidationError):
        PaymentRequest(customer_id="cust_1", amount=10, currency="JPY")
