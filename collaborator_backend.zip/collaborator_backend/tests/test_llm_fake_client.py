import pytest

from app.agents.customer_intelligence.models import CustomerInsights
from app.agents.sales.models import InterestLevel, SalesIntent, SalesTurnOutput
from app.llm.fake_client import FakeLLMClient


@pytest.fixture
def llm():
    return FakeLLMClient()


def test_ready_to_enroll_detected(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="Sign me up, I'm in!", schema=SalesTurnOutput
    )
    assert result.detected_intent == SalesIntent.READY_TO_ENROLL
    assert result.interest_level == InterestLevel.HIGH


def test_price_objection_detected(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="How much does it cost?", schema=SalesTurnOutput
    )
    assert result.detected_intent == SalesIntent.PRICING_QUESTION
    assert result.objection == "price"


def test_greeting_detected(llm):
    result = llm.generate_structured(system_prompt="sales", user_input="Hello!", schema=SalesTurnOutput)
    assert result.detected_intent == SalesIntent.GREETING


def test_general_question_fallback(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="What do you actually teach?", schema=SalesTurnOutput
    )
    assert result.detected_intent == SalesIntent.GENERAL_QUESTION


def test_customer_insights_detects_price_objection_and_low_intent(llm):
    result = llm.generate_structured(
        system_prompt="ci", user_input="Honestly the cost feels too expensive for me.", schema=CustomerInsights
    )
    assert "price" in result.objections
    assert result.intent_score < 0.5


def test_customer_insights_detects_high_interest(llm):
    result = llm.generate_structured(
        system_prompt="ci", user_input="This looks great, sign me up!", schema=CustomerInsights
    )
    assert "high_interest" in result.satisfaction_signals
    assert result.intent_score > 0.5


def test_skill_level_objection_detected(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="I've never coded before, is this too advanced for me?",
        schema=SalesTurnOutput,
    )
    assert result.objection == "skill_level"


def test_certificate_value_objection_detected(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="Is the certification actually recognized by employers?",
        schema=SalesTurnOutput,
    )
    assert result.objection == "certificate_value"


def test_in_person_preference_objection_detected(llm):
    result = llm.generate_structured(
        system_prompt="sales", user_input="I'd really prefer an in-person class.", schema=SalesTurnOutput
    )
    assert result.objection == "in_person_preference"


def test_customer_insights_detects_all_five_objection_categories(llm):
    result = llm.generate_structured(
        system_prompt="ci",
        user_input=(
            "It's too expensive and I'm quite busy. I've never coded before and I'm not sure "
            "the certificate is recognized. I'd also prefer an in-person class."
        ),
        schema=CustomerInsights,
    )
    assert set(result.objections) == {
        "price", "time_commitment", "skill_level", "certificate_value", "in_person_preference",
    }


def test_unknown_schema_raises_not_implemented(llm):
    class NotWired:
        pass

    with pytest.raises(NotImplementedError):
        llm.generate_structured(system_prompt="x", user_input="y", schema=NotWired)
