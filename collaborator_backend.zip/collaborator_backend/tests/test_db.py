from app.db import EventStore


def test_log_and_get_event():
    with EventStore() as store:
        event_id = store.log_event(
            agent="payment_agent",
            type_="payment_request",
            payload={"amount": 100, "customer_id": "cust_1"},
            status="pending",
        )
        record = store.get_event(event_id)

        assert record.agent == "payment_agent"
        assert record.type == "payment_request"
        assert record.status == "pending"
        assert record.payload == {"amount": 100, "customer_id": "cust_1"}


def test_update_event_status_merges_payload():
    with EventStore() as store:
        event_id = store.log_event(
            agent="security_agent",
            type_="alert",
            payload={"reason": "high_amount"},
            status="open",
        )
        updated = store.update_event_status(
            event_id, status="resolved", extra_payload={"resolved_by": "human"}
        )

        assert updated.status == "resolved"
        assert updated.payload == {"reason": "high_amount", "resolved_by": "human"}


def test_get_events_filters_by_agent_type_status():
    with EventStore() as store:
        store.log_event("payment_agent", "payment_request", {"n": 1}, "pending")
        store.log_event("payment_agent", "payment_result", {"n": 2}, "succeeded")
        store.log_event("security_agent", "alert", {"n": 3}, "open")

        payment_events = store.get_events(agent="payment_agent")
        assert len(payment_events) == 2

        alerts = store.get_events(agent="security_agent", type_="alert")
        assert len(alerts) == 1
        assert alerts[0].payload == {"n": 3}

        pending_only = store.get_events(status="pending")
        assert len(pending_only) == 1
        assert pending_only[0].payload == {"n": 1}


def test_get_event_missing_raises_keyerror():
    with EventStore() as store:
        try:
            store.get_event(999)
            assert False, "expected KeyError"
        except KeyError:
            pass
