from app.agents.security import rules
from app.db import EventStore


def _log_payment_request(store, customer_id, amount):
    return store.log_event(
        agent="payment_agent",
        type_="payment_request",
        payload={"customer_id": customer_id, "amount": amount},
        status="pending",
    )


def test_exceeds_threshold():
    assert rules.exceeds_threshold(500.0, threshold=500.0) is True
    assert rules.exceeds_threshold(499.99, threshold=500.0) is False


def test_check_velocity_flags_after_max_attempts():
    with EventStore() as store:
        for _ in range(3):
            _log_payment_request(store, "cust_1", 50.0)

        assert rules.check_velocity(store, "cust_1", max_attempts=3) is True
        assert rules.check_velocity(store, "cust_2", max_attempts=3) is False


def test_check_velocity_ignores_other_customers():
    with EventStore() as store:
        _log_payment_request(store, "cust_1", 50.0)
        _log_payment_request(store, "cust_1", 50.0)
        _log_payment_request(store, "cust_2", 50.0)

        assert rules.check_velocity(store, "cust_1", max_attempts=3) is False


def test_check_duplicate_requires_a_repeat_not_just_one_occurrence():
    with EventStore() as store:
        _log_payment_request(store, "cust_1", 120.0)

        # a single payment is not a duplicate of itself
        assert rules.check_duplicate(store, "cust_1", 120.0) is False
        assert rules.check_duplicate(store, "cust_1", 90.0) is False
        assert rules.check_duplicate(store, "cust_2", 120.0) is False


def test_check_duplicate_flags_a_genuine_repeat():
    with EventStore() as store:
        _log_payment_request(store, "cust_1", 120.0)
        _log_payment_request(store, "cust_1", 120.0)

        assert rules.check_duplicate(store, "cust_1", 120.0) is True
