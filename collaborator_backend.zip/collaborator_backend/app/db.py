"""Shared event store: audit log + inter-agent event feed.

Every agent action and payment event is written here as one row. This
single table is deliberately the audit trail, the inter-agent "shared
context" the orchestrator reads, and (later) the dashboard's data source
— one source of truth instead of three things that can drift apart.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    agent TEXT NOT NULL,
    type TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL
);
"""


@dataclass(frozen=True)
class EventRecord:
    id: int
    ts: datetime
    agent: str
    type: str
    payload: dict[str, Any]
    status: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class EventStore:
    """Thin wrapper around a single SQLite connection.

    One EventStore instance = one connection, kept open for the instance's
    lifetime so ``:memory:`` databases work (a fresh connection per call
    would otherwise lose the schema/data between calls).
    """

    def __init__(self, db_path: str = ":memory:"):
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute(SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "EventStore":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def log_event(
        self, agent: str, type_: str, payload: dict[str, Any], status: str
    ) -> int:
        cur = self._conn.execute(
            "INSERT INTO events (ts, agent, type, payload, status) VALUES (?, ?, ?, ?, ?)",
            (_now_iso(), agent, type_, json.dumps(payload), status),
        )
        self._conn.commit()
        return cur.lastrowid

    def update_event_status(
        self,
        event_id: int,
        status: str,
        extra_payload: Optional[dict[str, Any]] = None,
    ) -> EventRecord:
        row = self._conn.execute(
            "SELECT * FROM events WHERE id = ?", (event_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"no event with id {event_id}")

        payload = json.loads(row["payload"])
        if extra_payload:
            payload.update(extra_payload)

        self._conn.execute(
            "UPDATE events SET status = ?, payload = ? WHERE id = ?",
            (status, json.dumps(payload), event_id),
        )
        self._conn.commit()
        return self._row_to_record(
            {**dict(row), "status": status, "payload": json.dumps(payload)}
        )

    def get_event(self, event_id: int) -> EventRecord:
        row = self._conn.execute(
            "SELECT * FROM events WHERE id = ?", (event_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"no event with id {event_id}")
        return self._row_to_record(row)

    def get_events(
        self,
        agent: Optional[str] = None,
        type_: Optional[str] = None,
        status: Optional[str] = None,
    ) -> list[EventRecord]:
        clauses = []
        params: list[Any] = []
        if agent is not None:
            clauses.append("agent = ?")
            params.append(agent)
        if type_ is not None:
            clauses.append("type = ?")
            params.append(type_)
        if status is not None:
            clauses.append("status = ?")
            params.append(status)

        query = "SELECT * FROM events"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY id ASC"

        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_record(row) for row in rows]

    @staticmethod
    def _row_to_record(row: Any) -> EventRecord:
        return EventRecord(
            id=row["id"],
            ts=datetime.fromisoformat(row["ts"]),
            agent=row["agent"],
            type=row["type"],
            payload=json.loads(row["payload"]),
            status=row["status"],
        )
