"""Shared thresholds and constants for the FinTech agent team.

Centralized so the pitch/demo can point at one place for "here's how we
tuned risk controls" rather than magic numbers scattered across agents.
"""

# -- Payment risk thresholds --------------------------------------------

# Payments at or above this amount always require human approval before
# the Payment Agent is allowed to execute them.
MAX_AUTO_APPROVE_AMOUNT = 500.0

# A payment request below this amount is rejected outright as invalid
# rather than processed (guards against zero/negative amounts).
MIN_PAYMENT_AMOUNT = 0.01

SUPPORTED_CURRENCIES = {"USD", "EUR", "TND"}

# -- Velocity / anomaly detection ----------------------------------------

# How many payment attempts a single customer may make within the
# velocity window before the Security Agent flags them.
VELOCITY_WINDOW_SECONDS = 60
VELOCITY_MAX_ATTEMPTS = 3

# Two payments from the same customer for the same amount within this
# window are flagged as a likely duplicate/replay.
DUPLICATE_WINDOW_SECONDS = 30

# -- Least-privilege permission matrix ------------------------------------
# Each agent gets only the actions it needs. Enforced in
# app.agents.security.permissions.check_permission.
AGENT_PERMISSIONS = {
    "sales_agent": {"create_lead", "read_lead"},
    "customer_intelligence_agent": {"read_lead", "write_lead_insights"},
    "payment_agent": {"create_payment", "read_payment", "execute_payment"},
    "financial_data_analyst": {"read_payment", "read_lead", "read_events"},
    "business_strategy_agent": {"read_events", "read_lead"},
    "security_agent": {
        "read_events",
        "read_payment",
        "read_lead",
        "write_alert",
        "approve_payment",
        "deny_payment",
    },
}
