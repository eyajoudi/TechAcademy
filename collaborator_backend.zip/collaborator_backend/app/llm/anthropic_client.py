"""Real LLM backend — only imported/instantiated when an API key is
actually configured (see factory.py). Forces structured output via
tool-calling rather than parsing free text, matching FakeLLMClient's
contract exactly so agents never know which one they're talking to.
"""

from __future__ import annotations

from pydantic import BaseModel


class AnthropicLLMClient:
    def __init__(self, api_key: str, model: str = "claude-sonnet-5"):
        import anthropic  # lazy import: only needed if this class is actually used

        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    def generate_structured(self, *, system_prompt: str, user_input: str, schema: type[BaseModel]):
        tool = {
            "name": "emit_result",
            "description": f"Return the result as {schema.__name__}.",
            "input_schema": schema.model_json_schema(),
        }
        response = self._client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=system_prompt,
            tools=[tool],
            tool_choice={"type": "tool", "name": "emit_result"},
            messages=[{"role": "user", "content": user_input}],
        )
        tool_use = next(block for block in response.content if block.type == "tool_use")
        return schema.model_validate(tool_use.input)
