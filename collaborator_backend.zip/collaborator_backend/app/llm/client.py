"""The one interface every LLM-backed agent talks to.

Sales and Customer Intelligence agents depend on this Protocol only —
never on a concrete implementation. That's what makes it possible to
build and fully test both agents today with zero API key and zero cost
(FakeLLMClient), and later swap in a real model (Claude, a local Ollama
model, any free-tier provider) by changing only app/llm/factory.py.
"""

from __future__ import annotations

from typing import Protocol, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class LLMClient(Protocol):
    def generate_structured(self, *, system_prompt: str, user_input: str, schema: type[T]) -> T:
        """Return a validated instance of `schema` given the prompt + input.

        Implementations must force the output into `schema` (tool-calling /
        JSON mode / whatever the backend supports) rather than parse free
        text — see PLAN.md section 3 for why.
        """
        ...
