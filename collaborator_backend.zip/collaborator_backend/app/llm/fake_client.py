"""Deterministic, zero-cost, zero-network stand-in for a real LLM.

Rule/keyword-based rather than a model call, so it's fully unit-testable
and demoable with no API key, no budget, no internet dependency. Tuned to
the 9antra "AI Agents Bootcamp" narrative (PLAN.md section 1) so the demo
still reads coherently even if no real LLM is ever wired in.

Dispatches on the requested pydantic schema type — add a new `_fake_*`
function and a branch in `generate_structured` for each new structured
output an agent needs.
"""

from __future__ import annotations

from pydantic import BaseModel

from app.agents.business_strategy.models import BusinessStrategyReport, Recommendation
from app.agents.customer_intelligence.models import CustomerInsights
from app.agents.sales.models import InterestLevel, SalesIntent, SalesTurnOutput

_PRICE_KEYWORDS = ["price", "cost", "expensive", "cher", "combien", "budget"]
_TIME_KEYWORDS = ["busy", "time", "schedule", "no time", "too long"]
_SKILL_LEVEL_KEYWORDS = [
    "too advanced", "too hard", "beginner", "not experienced", "my level",
    "skill level", "too difficult", "never coded", "no experience", "not good enough",
]
_CERTIFICATE_KEYWORDS = [
    "certificate", "certification", "is it recognized", "accredited", "diploma", "worth it",
]
_IN_PERSON_KEYWORDS = [
    "in person", "in-person", "on site", "on-site", "face to face", "physical class",
    "classroom", "remote only",
]
_READY_KEYWORDS = [
    "sign me up", "i'm in", "im in", "enroll", "let's do it", "lets do it",
    "i want to join", "i'll take it", "ill take it", "yes please", "count me in",
]
_GREETING_KEYWORDS = ["hi", "hello", "bonjour", "salut", "hey"]
_CAREER_KEYWORDS = ["career", "job", "promotion", "hire", "hired", "work"]


def _fake_sales_turn(user_input: str) -> SalesTurnOutput:
    text = user_input.lower()

    if any(k in text for k in _READY_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "Great, let's get you enrolled in the 9antra AI Agents Bootcamp — "
                "I'll start a test payment for your seat now."
            ),
            detected_intent=SalesIntent.READY_TO_ENROLL,
            interest_level=InterestLevel.HIGH,
        )

    if any(k in text for k in _PRICE_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "The bootcamp is a one-time fee with a payment plan available — "
                "most learners say it pays for itself with the first project. "
                "Want me to walk you through what's included?"
            ),
            detected_intent=SalesIntent.PRICING_QUESTION,
            objection="price",
            interest_level=InterestLevel.MEDIUM,
        )

    if any(k in text for k in _TIME_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "Totally fair — the bootcamp is self-paced with weekly live sessions, "
                "so it fits around a full schedule."
            ),
            detected_intent=SalesIntent.OBJECTION,
            objection="time_commitment",
            interest_level=InterestLevel.MEDIUM,
        )

    if any(k in text for k in _SKILL_LEVEL_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "No prior experience needed — the first two weeks cover the fundamentals "
                "before anything advanced, and there's a short placement check to route you right."
            ),
            detected_intent=SalesIntent.OBJECTION,
            objection="skill_level",
            interest_level=InterestLevel.MEDIUM,
        )

    if any(k in text for k in _CERTIFICATE_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "The certificate is backed by a portfolio of real agent projects you build "
                "during the bootcamp — employers care more about the projects than the paper."
            ),
            detected_intent=SalesIntent.OBJECTION,
            objection="certificate_value",
            interest_level=InterestLevel.MEDIUM,
        )

    if any(k in text for k in _IN_PERSON_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "Most of the bootcamp runs online, but we host an in-person demo day "
                "at the end where you present your project live."
            ),
            detected_intent=SalesIntent.OBJECTION,
            objection="in_person_preference",
            interest_level=InterestLevel.MEDIUM,
        )

    if any(k in text for k in _GREETING_KEYWORDS):
        return SalesTurnOutput(
            reply_text=(
                "Hi! I'm here to tell you about the 9antra AI Agents Bootcamp — "
                "want a quick overview of what you'd build?"
            ),
            detected_intent=SalesIntent.GREETING,
            interest_level=InterestLevel.LOW,
        )

    return SalesTurnOutput(
        reply_text=(
            "Good question — the bootcamp covers building and deploying real multi-agent "
            "systems, with a portfolio project at the end. What matters most to you?"
        ),
        detected_intent=SalesIntent.GENERAL_QUESTION,
        interest_level=InterestLevel.LOW,
    )


def _fake_customer_insights(transcript_text: str) -> CustomerInsights:
    text = transcript_text.lower()

    objections: list[str] = []
    needs: list[str] = []
    motivations: list[str] = []
    satisfaction_signals: list[str] = []

    if any(k in text for k in _PRICE_KEYWORDS):
        objections.append("price")
    if any(k in text for k in _TIME_KEYWORDS):
        objections.append("time_commitment")
    if any(k in text for k in _SKILL_LEVEL_KEYWORDS):
        objections.append("skill_level")
    if any(k in text for k in _CERTIFICATE_KEYWORDS):
        objections.append("certificate_value")
    if any(k in text for k in _IN_PERSON_KEYWORDS):
        objections.append("in_person_preference")
    if any(k in text for k in _CAREER_KEYWORDS):
        motivations.append("career_growth")
        needs.append("practical_ai_skills")
    if any(k in text for k in _READY_KEYWORDS):
        satisfaction_signals.append("high_interest")

    if satisfaction_signals:
        intent_score = 0.85
    elif objections:
        intent_score = 0.35
    else:
        intent_score = 0.5

    return CustomerInsights(
        needs=needs,
        objections=objections,
        motivations=motivations,
        satisfaction_signals=satisfaction_signals,
        intent_score=intent_score,
    )


def _fake_business_strategy(summary_text: str) -> BusinessStrategyReport:
    # BusinessStrategyAgent builds this text itself (see _build_user_input),
    # so matching its fixed line format here is safe — not parsing arbitrary
    # free text, just reading back a report we control the shape of.
    text = summary_text.lower()
    recommendations: list[Recommendation] = []
    addressed: list[str] = []

    if "price" in text:
        recommendations.append(
            Recommendation(
                title="Introduce a payment plan or limited-time discount",
                rationale="Price was flagged as a top objection among analyzed leads.",
                priority="high",
            )
        )
        addressed.append("price")

    if "time_commitment" in text:
        recommendations.append(
            Recommendation(
                title="Emphasize the self-paced format earlier in the pitch",
                rationale="Time commitment was raised as an objection; the self-paced "
                "structure directly answers it.",
                priority="medium",
            )
        )
        addressed.append("time_commitment")

    if "skill_level" in text:
        recommendations.append(
            Recommendation(
                title="Add a free level check before enrollment",
                rationale="Skill-level concerns came up among analyzed leads; a short "
                "placement check reassures beginners and routes them to the right track.",
                priority="medium",
            )
        )
        addressed.append("skill_level")

    if "certificate_value" in text:
        recommendations.append(
            Recommendation(
                title="Lead with graduate project showcases in the pitch",
                rationale="Certificate value was questioned among analyzed leads; showing "
                "concrete graduate projects demonstrates value more directly than the credential itself.",
                priority="medium",
            )
        )
        addressed.append("certificate_value")

    if "in_person_preference" in text:
        recommendations.append(
            Recommendation(
                title="Mention the in-person demo day earlier in the pitch",
                rationale="A preference for in-person time came up among analyzed leads; "
                "the Sales agent should surface the demo day sooner.",
                priority="low",
            )
        )
        addressed.append("in_person_preference")

    if "security alerts: 0 " not in text:
        recommendations.append(
            Recommendation(
                title="Review flagged transactions before scaling outreach",
                rationale="Security alerts were recorded this period; resolve root causes "
                "before increasing lead volume.",
                priority="medium",
            )
        )

    if not recommendations:
        recommendations.append(
            Recommendation(
                title="Collect more lead interactions before drawing conclusions",
                rationale="Not enough signal yet in the data to recommend a specific change.",
                priority="low",
            )
        )

    return BusinessStrategyReport(
        summary=f"Generated {len(recommendations)} recommendation(s) from available lead and payment data.",
        recommendations=recommendations,
        top_objections_addressed=addressed,
    )


class FakeLLMClient:
    def generate_structured(self, *, system_prompt: str, user_input: str, schema: type[BaseModel]):
        if schema is SalesTurnOutput:
            return _fake_sales_turn(user_input)
        if schema is CustomerInsights:
            return _fake_customer_insights(user_input)
        if schema is BusinessStrategyReport:
            return _fake_business_strategy(user_input)
        raise NotImplementedError(f"FakeLLMClient has no fake handler for schema {schema.__name__}")
