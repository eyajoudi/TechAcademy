"""Single place that decides which LLMClient implementation agents get.

Default: FakeLLMClient (zero cost, zero key, fully deterministic) — the
whole prototype builds and demos today without this ever changing. Set
ANTHROPIC_API_KEY in the environment once budget/a key is available and
every agent using get_llm_client() switches to real Claude calls with no
code change anywhere else.
"""

from __future__ import annotations

import os

from app.llm.client import LLMClient
from app.llm.fake_client import FakeLLMClient


def get_llm_client() -> LLMClient:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if api_key:
        from app.llm.anthropic_client import AnthropicLLMClient

        return AnthropicLLMClient(api_key=api_key)
    return FakeLLMClient()
