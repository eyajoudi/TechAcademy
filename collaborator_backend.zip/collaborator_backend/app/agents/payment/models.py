from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, field_validator

from app.config import MIN_PAYMENT_AMOUNT, SUPPORTED_CURRENCIES


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PENDING_APPROVAL = "pending_approval"
    SUCCEEDED = "succeeded"
    DECLINED = "declined"  # the simulated processor itself said no
    BLOCKED = "blocked"  # auto-denied by Security before ever reaching the processor


class PaymentRequest(BaseModel):
    customer_id: str
    amount: float
    currency: str = "USD"
    payment_method_token: str = "tok_visa"
    memo: str = ""

    @field_validator("amount")
    @classmethod
    def amount_must_be_positive(cls, value: float) -> float:
        if value < MIN_PAYMENT_AMOUNT:
            raise ValueError(f"amount must be >= {MIN_PAYMENT_AMOUNT}")
        return value

    @field_validator("currency")
    @classmethod
    def currency_must_be_supported(cls, value: str) -> str:
        if value not in SUPPORTED_CURRENCIES:
            raise ValueError(f"unsupported currency '{value}', expected one of {SUPPORTED_CURRENCIES}")
        return value


class PaymentResult(BaseModel):
    event_id: int
    status: PaymentStatus
    customer_id: str
    amount: float
    currency: str
    reason: Optional[str] = None
