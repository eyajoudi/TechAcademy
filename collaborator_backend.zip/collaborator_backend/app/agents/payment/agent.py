"""Payment Agent.

Deliberately narrow: this agent knows how to create a payment record,
run the simulated checkout state machine, and transition a record to
pending-approval or denied. It does NOT know about the Security Agent's
screening rules, and it does not decide *when* a human should be
involved — that sequencing is the SupervisingAgent's job
(app/agents/supervisor/agent.py), which is the only thing that "links"
specialist agents together. Keeping this agent single-purpose is what
lets it be swapped, tested, or replaced without touching the workflow.

The one thing this agent still does for itself: self-enforce its own
execute/create permissions via the Security Agent before acting. That's
defense-in-depth, not routing — an agent should never trust "go ahead"
without checking its own permission, even when told to proceed by the
Supervisor.

Outcomes are deterministic by payment_method_token (mirrors how Stripe's
own test-mode cards work), so the pipeline is reproducible in tests and
demoable: use "tok_decline_generic" live on stage to show a clean decline.
"""

from __future__ import annotations

from typing import Optional

from app.agents.payment.models import PaymentRequest, PaymentResult, PaymentStatus
from app.agents.security.agent import SecurityAgent
from app.db import EventStore

_DECLINE_TOKENS = {
    "tok_decline_generic": "generic_decline",
    "tok_decline_insufficient_funds": "insufficient_funds",
    "tok_decline_expired_card": "expired_card",
}


def _simulate_outcome(payment_method_token: str) -> tuple[PaymentStatus, Optional[str]]:
    if payment_method_token in _DECLINE_TOKENS:
        return PaymentStatus.DECLINED, _DECLINE_TOKENS[payment_method_token]
    return PaymentStatus.SUCCEEDED, None


class PaymentAgent:
    def __init__(self, store: EventStore, security_agent: SecurityAgent):
        self.store = store
        self.security = security_agent

    def create_request(self, request: PaymentRequest) -> int:
        """Log a new payment attempt and return its event id. Does not execute it."""
        self.security.authorize("payment_agent", "create_payment")
        return self.store.log_event(
            agent="payment_agent",
            type_="payment_request",
            payload={
                "customer_id": request.customer_id,
                "amount": request.amount,
                "currency": request.currency,
                "payment_method_token": request.payment_method_token,
            },
            status=PaymentStatus.PENDING.value,
        )

    def execute(self, event_id: int, request: PaymentRequest) -> PaymentResult:
        """Run the simulated checkout and record the outcome."""
        self.security.authorize("payment_agent", "execute_payment")
        status, reason = _simulate_outcome(request.payment_method_token)

        self.store.update_event_status(
            event_id, status=status.value, extra_payload={"reason": reason}
        )
        return PaymentResult(
            event_id=event_id,
            status=status,
            customer_id=request.customer_id,
            amount=request.amount,
            currency=request.currency,
            reason=reason,
        )

    def mark_pending_approval(
        self, event_id: int, alerts: list[str], risk_score: float
    ) -> PaymentResult:
        updated = self.store.update_event_status(
            event_id,
            status=PaymentStatus.PENDING_APPROVAL.value,
            extra_payload={"security_alerts": alerts, "risk_score": risk_score},
        )
        return PaymentResult(
            event_id=event_id,
            status=PaymentStatus.PENDING_APPROVAL,
            customer_id=updated.payload["customer_id"],
            amount=updated.payload["amount"],
            currency=updated.payload["currency"],
            reason="; ".join(alerts),
        )

    def mark_blocked(self, event_id: int, alerts: list[str]) -> PaymentResult:
        """Auto-deny a request the Security Agent found unambiguous enough to
        reject outright (e.g. a prompt-injection attempt) — no human step,
        straight from pending to blocked. Distinct from a processor decline:
        this request never reached the simulated processor at all."""
        updated = self.store.update_event_status(
            event_id,
            status=PaymentStatus.BLOCKED.value,
            extra_payload={"reason": "; ".join(alerts), "security_alerts": alerts},
        )
        return PaymentResult(
            event_id=event_id,
            status=PaymentStatus.BLOCKED,
            customer_id=updated.payload["customer_id"],
            amount=updated.payload["amount"],
            currency=updated.payload["currency"],
            reason="; ".join(alerts),
        )

    def resolve_denied(self, event_id: int, reason: str) -> PaymentResult:
        self._require_status(event_id, PaymentStatus.PENDING_APPROVAL)
        updated = self.store.update_event_status(
            event_id,
            status=PaymentStatus.DECLINED.value,
            extra_payload={"reason": f"denied by human reviewer: {reason}"},
        )
        return PaymentResult(
            event_id=event_id,
            status=PaymentStatus.DECLINED,
            customer_id=updated.payload["customer_id"],
            amount=updated.payload["amount"],
            currency=updated.payload["currency"],
            reason=updated.payload.get("reason"),
        )

    def request_from_event(self, event_id: int) -> PaymentRequest:
        """Rebuild a PaymentRequest from a pending_approval event's stored payload.

        Raises if the event isn't currently pending approval — this is what
        prevents a resolved payment from being re-executed by a stray
        approve() call.
        """
        event = self._require_status(event_id, PaymentStatus.PENDING_APPROVAL)
        return PaymentRequest(
            customer_id=event.payload["customer_id"],
            amount=event.payload["amount"],
            currency=event.payload["currency"],
            payment_method_token=event.payload["payment_method_token"],
        )

    def _require_status(self, event_id: int, expected: PaymentStatus):
        event = self.store.get_event(event_id)
        if event.status != expected.value:
            raise ValueError(
                f"event {event_id} is not {expected.value} (current status={event.status})"
            )
        return event
