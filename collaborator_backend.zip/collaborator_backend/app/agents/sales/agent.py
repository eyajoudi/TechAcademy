"""Sales Agent.

Narrow, like every other agent in this system: it knows how to produce
one conversational turn (reply + structured read on the customer) and
log it. It does not decide when to hand off to Customer Intelligence or
Payment — that sequencing belongs to the SupervisingAgent.
"""

from __future__ import annotations

from app.agents.sales.models import SalesTurnOutput
from app.db import EventStore
from app.llm.client import LLMClient

_SYSTEM_PROMPT = (
    "You are the Sales Agent for 9antra's AI Agents Bootcamp. Present the offer, "
    "answer questions, handle objections honestly, and gauge the customer's interest. "
    "Keep replies short and concrete."
)


class SalesAgent:
    def __init__(self, store: EventStore, llm_client: LLMClient):
        self.store = store
        self.llm = llm_client

    def handle_turn(self, lead_id: str, customer_message: str) -> SalesTurnOutput:
        output = self.llm.generate_structured(
            system_prompt=_SYSTEM_PROMPT,
            user_input=customer_message,
            schema=SalesTurnOutput,
        )

        self.store.log_event(
            agent="sales_agent",
            type_="sales_turn",
            payload={
                "lead_id": lead_id,
                "customer_message": customer_message,
                "reply_text": output.reply_text,
                "detected_intent": output.detected_intent.value,
                "objection": output.objection,
                "interest_level": output.interest_level.value,
            },
            status=output.interest_level.value,
        )
        return output
