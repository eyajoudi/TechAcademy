from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel


class SalesIntent(str, Enum):
    GREETING = "greeting"
    PRICING_QUESTION = "pricing_question"
    OBJECTION = "objection"
    READY_TO_ENROLL = "ready_to_enroll"
    GENERAL_QUESTION = "general_question"


class InterestLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SalesTurnOutput(BaseModel):
    reply_text: str
    detected_intent: SalesIntent
    objection: Optional[str] = None
    interest_level: InterestLevel
