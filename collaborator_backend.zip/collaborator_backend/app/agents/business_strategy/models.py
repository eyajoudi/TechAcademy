from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Recommendation(BaseModel):
    title: str
    rationale: str
    priority: Literal["low", "medium", "high"]


class BusinessStrategyReport(BaseModel):
    summary: str
    recommendations: list[Recommendation] = Field(default_factory=list)
    top_objections_addressed: list[str] = Field(default_factory=list)
