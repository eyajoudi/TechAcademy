"""Business Strategy Agent.

Reads Customer Intelligence's accumulated insights directly from the
shared EventStore — the same "aggregator reads shared context itself"
pattern the Financial Data Analyst uses — and combines them with a
FinancialReport handed to it by the Supervisor, to produce ranked,
data-grounded recommendations for improving the sales script, offer, and
customer journey. Matches the cahier des charges' description of this
role: "Analyser les résultats et feedbacks ; Recommander / proposer des
améliorations du script commercial, de l'offre et du parcours client."

Holds no reference to any other agent — only to the shared store (to
read Customer Intelligence's own logged events, the same kind of
cross-agent read the Financial Analyst already does for Payment/Security
events) and to the LLMClient. The FinancialReport itself is passed in by
the Supervisor rather than fetched here, so this agent never needs a
direct reference to the Financial Data Analyst object.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

from app.agents.business_strategy.models import BusinessStrategyReport
from app.agents.financial_analyst.models import FinancialReport
from app.db import EventStore
from app.llm.client import LLMClient

_SYSTEM_PROMPT = (
    "You are the Business Strategy Agent for 9antra's AI Agents Bootcamp sales flow. "
    "Given the financial results and the aggregated customer feedback, recommend concrete, "
    "prioritized improvements to the sales script, the offer, and the customer journey. "
    "Ground every recommendation in the data you were given."
)


@dataclass
class AggregatedInsights:
    objections: list[str] = field(default_factory=list)
    needs: list[str] = field(default_factory=list)
    motivations: list[str] = field(default_factory=list)
    satisfaction_signals: list[str] = field(default_factory=list)
    average_intent_score: float = 0.5
    leads_analyzed: int = 0


class BusinessStrategyAgent:
    def __init__(self, store: EventStore, llm_client: LLMClient):
        self.store = store
        self.llm = llm_client

    def generate_recommendations(self, financial_report: FinancialReport) -> BusinessStrategyReport:
        insights = self._aggregate_customer_insights()
        user_input = self._build_user_input(financial_report, insights)

        report = self.llm.generate_structured(
            system_prompt=_SYSTEM_PROMPT, user_input=user_input, schema=BusinessStrategyReport
        )

        self.store.log_event(
            agent="business_strategy_agent",
            type_="recommendations",
            payload=report.model_dump(),
            status="completed",
        )
        return report

    def _aggregate_customer_insights(self) -> AggregatedInsights:
        events = self.store.get_events(agent="customer_intelligence_agent", type_="customer_insights")

        objections: list[str] = []
        needs: list[str] = []
        motivations: list[str] = []
        satisfaction: list[str] = []
        scores: list[float] = []

        for event in events:
            objections.extend(event.payload.get("objections", []))
            needs.extend(event.payload.get("needs", []))
            motivations.extend(event.payload.get("motivations", []))
            satisfaction.extend(event.payload.get("satisfaction_signals", []))
            scores.append(event.payload.get("intent_score", 0.5))

        return AggregatedInsights(
            objections=objections,
            needs=needs,
            motivations=motivations,
            satisfaction_signals=satisfaction,
            average_intent_score=(sum(scores) / len(scores)) if scores else 0.5,
            leads_analyzed=len(events),
        )

    @staticmethod
    def _build_user_input(financial_report: FinancialReport, insights: AggregatedInsights) -> str:
        top_objections = [item for item, _ in Counter(insights.objections).most_common(5)]
        lines = [
            f"Leads analyzed: {insights.leads_analyzed}",
            f"Average purchase intent score: {insights.average_intent_score:.2f}",
            f"Top objections: {', '.join(top_objections) or 'none recorded'}",
            f"Needs mentioned: {', '.join(sorted(set(insights.needs))) or 'none recorded'}",
            f"Motivations: {', '.join(sorted(set(insights.motivations))) or 'none recorded'}",
            f"Payments succeeded: {financial_report.payments_succeeded}",
            f"Payments declined: {financial_report.payments_declined}",
            f"Payments pending approval: {financial_report.payments_pending_approval}",
            f"Revenue by currency: {financial_report.revenue_by_currency}",
            f"Security alerts: {financial_report.security_alerts_count} "
            f"(breakdown: {financial_report.security_alert_breakdown})",
        ]
        return "\n".join(lines)
