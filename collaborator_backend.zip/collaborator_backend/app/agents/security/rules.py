"""Deterministic anomaly-detection rules for payment events.

All rules read from the shared EventStore, which is also the audit log —
so "what triggered this flag" is always answerable by pointing at prior
rows, not a hidden model decision.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.config import (
    DUPLICATE_WINDOW_SECONDS,
    MAX_AUTO_APPROVE_AMOUNT,
    VELOCITY_MAX_ATTEMPTS,
    VELOCITY_WINDOW_SECONDS,
)
from app.db import EventStore


def exceeds_threshold(amount: float, threshold: float = MAX_AUTO_APPROVE_AMOUNT) -> bool:
    return amount >= threshold


def check_velocity(
    store: EventStore,
    customer_id: str,
    *,
    now: datetime | None = None,
    window_seconds: int = VELOCITY_WINDOW_SECONDS,
    max_attempts: int = VELOCITY_MAX_ATTEMPTS,
) -> bool:
    """True if customer_id has hit >= max_attempts payment requests within window_seconds."""
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(seconds=window_seconds)

    recent = [
        event
        for event in store.get_events(agent="payment_agent", type_="payment_request")
        if event.payload.get("customer_id") == customer_id and event.ts >= cutoff
    ]
    return len(recent) >= max_attempts


def check_duplicate(
    store: EventStore,
    customer_id: str,
    amount: float,
    *,
    now: datetime | None = None,
    window_seconds: int = DUPLICATE_WINDOW_SECONDS,
) -> bool:
    """True if the same customer+amount shows up more than once within window_seconds.

    PaymentAgent logs the payment_request row *before* screening, so the
    request being screened is always present in the store as one match —
    ">= 2" is what actually means "this is a repeat", not the first one.
    """
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(seconds=window_seconds)

    duplicates = [
        event
        for event in store.get_events(agent="payment_agent", type_="payment_request")
        if event.payload.get("customer_id") == customer_id
        and event.payload.get("amount") == amount
        and event.ts >= cutoff
    ]
    return len(duplicates) >= 2
