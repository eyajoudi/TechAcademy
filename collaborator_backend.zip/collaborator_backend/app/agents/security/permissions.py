"""Least-privilege enforcement.

Every agent has an explicit allow-list of actions in app.config.AGENT_PERMISSIONS.
Nothing is permitted by default — an agent not listed, or an action not in
its list, is denied.
"""

from __future__ import annotations

from app.config import AGENT_PERMISSIONS


class PermissionDenied(Exception):
    pass


def check_permission(agent: str, action: str) -> bool:
    allowed_actions = AGENT_PERMISSIONS.get(agent)
    if allowed_actions is None:
        return False
    return action in allowed_actions


def enforce_permission(agent: str, action: str) -> None:
    if not check_permission(agent, action):
        raise PermissionDenied(f"agent '{agent}' is not permitted to perform '{action}'")
