"""Security & Fraud Detection Agent.

Combines the permission matrix, anomaly rules, and prompt-injection
guardrails into one screening pass other agents call before a sensitive
action. Every screen — clear or flagged — is written to the shared
EventStore, so the result is simultaneously the audit trail.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.agents.security import guardrails, rules
from app.agents.security.guardrails import InjectionScanResult
from app.agents.security.permissions import PermissionDenied, enforce_permission
from app.db import EventStore


@dataclass(frozen=True)
class SecurityScreenResult:
    event_id: int
    flagged: bool
    requires_human_approval: bool
    blocked: bool = False
    alerts: list[str] = field(default_factory=list)
    risk_score: float = 0.0
    injection_scan: InjectionScanResult = field(default_factory=InjectionScanResult)


class SecurityAgent:
    def __init__(self, store: EventStore):
        self.store = store

    def authorize(self, agent: str, action: str) -> None:
        """Raise PermissionDenied (and log the attempt) if agent can't do action."""
        try:
            enforce_permission(agent, action)
        except PermissionDenied as exc:
            self.store.log_event(
                agent="security_agent",
                type_="permission_check",
                payload={"requesting_agent": agent, "action": action, "reason": str(exc)},
                status="denied",
            )
            raise

    def screen_payment(
        self, *, customer_id: str, amount: float, memo: str = ""
    ) -> SecurityScreenResult:
        alerts: list[str] = []
        risk_score = 0.0

        if rules.exceeds_threshold(amount):
            alerts.append(f"amount {amount} meets or exceeds auto-approve threshold")
            risk_score += 0.5

        if rules.check_velocity(self.store, customer_id):
            alerts.append(f"velocity check failed for customer '{customer_id}'")
            risk_score += 0.3

        if rules.check_duplicate(self.store, customer_id, amount):
            alerts.append(f"possible duplicate payment for customer '{customer_id}'")
            risk_score += 0.3

        injection_scan = guardrails.scan_for_injection(memo)
        if injection_scan.flagged:
            alerts.append(
                f"possible prompt injection in memo: {injection_scan.matched_patterns}"
            )
            risk_score += injection_scan.risk_score

        risk_score = min(risk_score, 1.0)
        flagged = bool(alerts)
        # Prompt injection is an unambiguous manipulation attempt — auto-deny,
        # no human judgment call needed. Amount/velocity/duplicate anomalies
        # are judgment calls, so they route to a human instead of auto-denying.
        blocked = injection_scan.flagged

        if blocked:
            status = "blocked"
        elif flagged:
            status = "flagged"
        else:
            status = "clear"

        event_id = self.store.log_event(
            agent="security_agent",
            type_="payment_screen",
            payload={
                "customer_id": customer_id,
                "amount": amount,
                "alerts": alerts,
                "risk_score": risk_score,
                "requires_human_approval": flagged and not blocked,
                "blocked": blocked,
            },
            status=status,
        )

        return SecurityScreenResult(
            event_id=event_id,
            flagged=flagged,
            requires_human_approval=flagged and not blocked,
            blocked=blocked,
            alerts=alerts,
            risk_score=risk_score,
            injection_scan=injection_scan,
        )
