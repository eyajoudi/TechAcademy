"""Heuristic prompt-injection / manipulation screening.

Rule-based on purpose: for the demo we want to be able to show judges
*exactly* why a message was flagged, rather than point at an opaque model
call. Each pattern is named and weighted; the scan result carries which
ones fired so the Security Agent (and the dashboard later) can display
the reasoning.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# (name, pattern, weight) — weight is how much one match contributes to risk_score.
_PATTERNS: list[tuple[str, re.Pattern[str], float]] = [
    (
        "instruction_override",
        re.compile(
            r"\b(ignore|disregard|forget)\b.{0,20}\b(previous|prior|above|all)\b.{0,20}\b(instructions?|rules?|prompt)\b",
            re.IGNORECASE,
        ),
        0.6,
    ),
    (
        "role_override",
        re.compile(
            r"\b(you are now|act as|pretend to be|from now on you)\b",
            re.IGNORECASE,
        ),
        0.4,
    ),
    (
        "reveal_system_prompt",
        re.compile(
            r"\b(reveal|show|print|repeat)\b.{0,20}\b(system prompt|instructions|your prompt)\b",
            re.IGNORECASE,
        ),
        0.5,
    ),
    (
        "jailbreak_persona",
        re.compile(r"\b(do anything now|dan mode|developer mode|no restrictions)\b", re.IGNORECASE),
        0.6,
    ),
    (
        "sensitive_financial_command",
        re.compile(
            r"\b(approve|authorize|transfer|refund|release)\b.{0,25}\$?\d",
            re.IGNORECASE,
        ),
        0.7,
    ),
    (
        "privilege_escalation",
        re.compile(r"\b(grant|give)\b.{0,15}\b(admin|root|full access)\b", re.IGNORECASE),
        0.7,
    ),
    (
        "decision_override_keyword",
        re.compile(r"\b(decision\s*[:=]\s*allow|status\s*[:=]\s*allow|force\s*allow|set\s*allow)\b", re.IGNORECASE),
        0.8,
    ),
    (
        "authority_override",
        re.compile(
            r"\b(override|bypass|disable|skip)\b.{0,20}\b(security|verification|check|control|review)\b",
            re.IGNORECASE,
        ),
        0.8,
    ),
    (
        "override_phrase",
        re.compile(r"\b(system override|admin override|override mode|mode override)\b", re.IGNORECASE),
        0.6,
    ),
    # Social-engineering style pressure: claims of authority or urgency used to
    # push a sensitive action through without the usual checks. Weighted
    # lighter individually than a hard injection match — these phrasings can
    # overlap with legitimate urgent requests, so it takes two to flag.
    (
        "compliance_pressure",
        re.compile(
            r"\b(you must|you have to|you're required to|as an ai you)\b.{0,25}"
            r"\b(approve|authorize|comply|allow|obey)\b",
            re.IGNORECASE,
        ),
        0.5,
    ),
    (
        "urgent_unconditional_approval",
        re.compile(
            r"\b(approve|authorize)\b.{0,20}"
            r"\b(immediately|right away|no questions|without review|without delay)\b",
            re.IGNORECASE,
        ),
        0.4,
    ),
    (
        "false_authority_claim",
        re.compile(
            r"\b(admin says|on behalf of (the )?admin|i am the admin|i'm the admin|"
            r"this is the (owner|director|manager)|i am the (owner|director|manager))\b",
            re.IGNORECASE,
        ),
        0.5,
    ),
    (
        "card_data_in_message",
        re.compile(r"\b(?:\d[ -]?){13,19}\b"),
        1.0,  # unambiguous — a card-number-shaped sequence alone is enough to flag
    ),
]

FLAG_THRESHOLD = 0.4


@dataclass(frozen=True)
class InjectionScanResult:
    matched_patterns: list[str] = field(default_factory=list)
    risk_score: float = 0.0
    flagged: bool = False


def scan_for_injection(text: str) -> InjectionScanResult:
    if not text:
        return InjectionScanResult()

    matched: list[str] = []
    score = 0.0
    for name, pattern, weight in _PATTERNS:
        if pattern.search(text):
            matched.append(name)
            score += weight

    score = min(score, 1.0)
    return InjectionScanResult(
        matched_patterns=matched,
        risk_score=score,
        flagged=score >= FLAG_THRESHOLD,
    )
