from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class FinancialReport(BaseModel):
    payments_succeeded: int = 0
    payments_declined: int = 0
    payments_blocked: int = 0  # auto-denied by Security before reaching the processor
    payments_pending_approval: int = 0
    total_payment_attempts: int = 0
    revenue_by_currency: dict[str, float] = Field(default_factory=dict)

    security_alerts_count: int = 0  # flagged (needs review) + blocked (auto-denied)
    security_blocked_count: int = 0  # the subset that was auto-denied outright
    security_alert_breakdown: dict[str, int] = Field(default_factory=dict)

    human_decisions_approved: int = 0
    human_decisions_denied: int = 0

    # Require conversation data from the Sales / Customer Intelligence agents,
    # which don't exist yet — left unset rather than fabricated.
    conversion_rate: Optional[float] = None
    top_objections: Optional[list[str]] = None
    satisfaction_score: Optional[float] = None
