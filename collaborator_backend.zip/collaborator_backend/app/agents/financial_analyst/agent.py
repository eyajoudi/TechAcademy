"""Financial Data Analyst Agent.

Purely a read-side aggregator over the shared EventStore — no LLM calls,
no writes, no dependency on any other agent. Turns the Security/Payment
agents' audit trail into the dashboard-ready KPIs the cahier des charges
requires (section 4: ventes, revenus simulés, statuts de paiement,
alertes de sécurité).

Lead/conversation-derived metrics (conversion rate, top objections,
satisfaction) stay None until the Sales/Customer Intelligence agents
exist and start writing that data to the store — reporting "not yet
available" beats fabricating a number.
"""

from __future__ import annotations

from app.agents.financial_analyst.models import FinancialReport
from app.db import EventStore

# Alert category -> the substring SecurityAgent uses in its alert messages.
# Keeping this as plain keyword matching (rather than a new structured field
# on SecurityScreenResult) avoids touching the already-tested Security Agent
# just to get a reporting breakdown — a screen's alert list is already
# explainable English, so this is readable to a human auditing the trail too.
_ALERT_CATEGORY_KEYWORDS = {
    "amount_threshold": "exceeds auto-approve threshold",
    "velocity": "velocity check failed",
    "duplicate_payment": "possible duplicate payment",
    "prompt_injection": "possible prompt injection",
}


class FinancialDataAnalystAgent:
    def __init__(self, store: EventStore):
        self.store = store

    def generate_report(self) -> FinancialReport:
        payment_events = self.store.get_events(agent="payment_agent", type_="payment_request")
        screens = self.store.get_events(agent="security_agent", type_="payment_screen")
        decisions = self.store.get_events(agent="security_agent", type_="human_decision")

        revenue_by_currency: dict[str, float] = {}
        succeeded = declined = blocked = pending_approval = 0

        for event in payment_events:
            if event.status == "succeeded":
                succeeded += 1
                currency = event.payload.get("currency", "USD")
                amount = event.payload.get("amount", 0.0)
                revenue_by_currency[currency] = revenue_by_currency.get(currency, 0.0) + amount
            elif event.status == "declined":
                declined += 1
            elif event.status == "blocked":
                blocked += 1
            elif event.status == "pending_approval":
                pending_approval += 1

        alert_screens = [s for s in screens if s.status in ("flagged", "blocked")]
        blocked_screens = [s for s in screens if s.status == "blocked"]
        alert_breakdown = {category: 0 for category in _ALERT_CATEGORY_KEYWORDS}
        for screen in alert_screens:
            alerts = screen.payload.get("alerts", [])
            for category, keyword in _ALERT_CATEGORY_KEYWORDS.items():
                if any(keyword in alert for alert in alerts):
                    alert_breakdown[category] += 1

        approved = sum(1 for d in decisions if d.payload.get("decision") == "approve")
        denied = sum(1 for d in decisions if d.payload.get("decision") == "deny")

        return FinancialReport(
            payments_succeeded=succeeded,
            payments_declined=declined,
            payments_blocked=blocked,
            payments_pending_approval=pending_approval,
            total_payment_attempts=len(payment_events),
            revenue_by_currency=revenue_by_currency,
            security_alerts_count=len(alert_screens),
            security_blocked_count=len(blocked_screens),
            security_alert_breakdown=alert_breakdown,
            human_decisions_approved=approved,
            human_decisions_denied=denied,
        )
