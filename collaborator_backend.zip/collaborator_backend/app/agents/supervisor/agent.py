"""Supervising Agent — the single coordinator "above" all specialist agents.

This is deliberately NOT a generic orchestration framework (no graph
library, no external orchestrator). It's one hand-written class that
owns the *sequence* of the workflow: who gets called after whom, when to
pause for a human, and what happens when a stage fails. Each specialist
agent (Sales, Customer Intelligence, Security, Payment, Financial Data
Analyst, Business Strategy) stays narrow and has no idea the others
exist — the Supervisor is the only thing that links them.

This directly targets the cahier des charges' pillar-1 requirement:
"Orchestration, communication, partage de contexte et gestion des
erreurs entre agents." Every routing decision and every error is written
to the shared EventStore under agent="supervisor_agent", so the
workflow's own decisions are as traceable as the specialist agents' work.
"""

from __future__ import annotations

from app.agents.business_strategy.agent import BusinessStrategyAgent
from app.agents.business_strategy.models import BusinessStrategyReport
from app.agents.customer_intelligence.agent import CustomerIntelligenceAgent
from app.agents.customer_intelligence.models import CustomerInsights
from app.agents.financial_analyst.agent import FinancialDataAnalystAgent
from app.agents.financial_analyst.models import FinancialReport
from app.agents.payment.agent import PaymentAgent
from app.agents.payment.models import PaymentRequest, PaymentResult
from app.agents.sales.agent import SalesAgent
from app.agents.sales.models import SalesTurnOutput
from app.agents.security.agent import SecurityAgent
from app.db import EventStore


class SupervisorAgent:
    def __init__(
        self,
        store: EventStore,
        security_agent: SecurityAgent,
        payment_agent: PaymentAgent,
        financial_analyst: FinancialDataAnalystAgent,
        sales_agent: SalesAgent,
        customer_intelligence_agent: CustomerIntelligenceAgent,
        business_strategy_agent: BusinessStrategyAgent,
    ):
        self.store = store
        self.security = security_agent
        self.payment = payment_agent
        self.financial_analyst = financial_analyst
        self.sales = sales_agent
        self.customer_intelligence = customer_intelligence_agent
        self.business_strategy = business_strategy_agent

    def submit_payment(self, request: PaymentRequest) -> PaymentResult:
        event_id = self._run_stage("create_request", lambda: self.payment.create_request(request))

        screen = self._run_stage(
            "security_screen",
            lambda: self.security.screen_payment(
                customer_id=request.customer_id, amount=request.amount, memo=request.memo
            ),
        )

        if screen.blocked:
            self._log_routing_decision(event_id, "auto_block", screen.alerts)
            return self._run_stage(
                "mark_blocked", lambda: self.payment.mark_blocked(event_id, screen.alerts)
            )

        # Every payment remains human-gated, including low-risk requests.
        # A clean security screen is not itself a financial authorization.
        approval_reasons = list(screen.alerts)
        if not approval_reasons:
            approval_reasons.append("Contrôle automatique favorable ; validation humaine obligatoire avant simulation.")
        self._log_routing_decision(event_id, "route_to_human_approval", approval_reasons)
        return self._run_stage(
            "mark_pending_approval",
            lambda: self.payment.mark_pending_approval(event_id, approval_reasons, screen.risk_score),
        )

    def approve_payment(self, event_id: int, approver: str) -> PaymentResult:
        self._run_stage(
            "authorize_approval",
            lambda: self.security.authorize("security_agent", "approve_payment"),
        )
        self.store.log_event(
            agent="security_agent",
            type_="human_decision",
            payload={"event_id": event_id, "decision": "approve", "approver": approver},
            status="approved",
        )
        request = self._run_stage(
            "rebuild_request_from_event", lambda: self.payment.request_from_event(event_id)
        )
        self._log_routing_decision(event_id, "human_approved_execute", [])
        return self._run_stage("execute_payment", lambda: self.payment.execute(event_id, request))

    def deny_payment(self, event_id: int, approver: str, reason: str) -> PaymentResult:
        self._run_stage(
            "authorize_denial",
            lambda: self.security.authorize("security_agent", "deny_payment"),
        )
        self.store.log_event(
            agent="security_agent",
            type_="human_decision",
            payload={"event_id": event_id, "decision": "deny", "approver": approver, "reason": reason},
            status="denied",
        )
        self._log_routing_decision(event_id, "human_denied", [reason])
        return self._run_stage(
            "resolve_denied", lambda: self.payment.resolve_denied(event_id, reason)
        )

    def handle_sales_turn(self, lead_id: str, customer_message: str) -> SalesTurnOutput:
        return self._run_stage(
            "sales_turn", lambda: self.sales.handle_turn(lead_id, customer_message)
        )

    def run_customer_intelligence(self, lead_id: str) -> CustomerInsights:
        def _analyze():
            turns = [
                event
                for event in self.store.get_events(agent="sales_agent", type_="sales_turn")
                if event.payload.get("lead_id") == lead_id
            ]
            transcript = [turn.payload["customer_message"] for turn in turns]
            return self.customer_intelligence.analyze_transcript(lead_id, transcript)

        return self._run_stage("customer_intelligence", _analyze)

    def generate_financial_report(self) -> FinancialReport:
        return self._run_stage(
            "generate_financial_report", lambda: self.financial_analyst.generate_report()
        )

    def generate_business_strategy(self) -> BusinessStrategyReport:
        financial_report = self._run_stage(
            "generate_financial_report_for_strategy", lambda: self.financial_analyst.generate_report()
        )
        return self._run_stage(
            "generate_business_strategy",
            lambda: self.business_strategy.generate_recommendations(financial_report),
        )

    def _run_stage(self, stage: str, fn):
        """Run one workflow stage; on failure, log it to the audit trail and
        re-raise the *original* exception unchanged, so callers can still
        catch specific error types (e.g. PermissionDenied) while the
        shared event log keeps a full record of what broke and where."""
        try:
            return fn()
        except Exception as exc:
            self.store.log_event(
                agent="supervisor_agent",
                type_="error",
                payload={"stage": stage, "error": str(exc), "error_type": type(exc).__name__},
                status="error",
            )
            raise

    def _log_routing_decision(self, event_id: int, decision: str, alerts: list[str]) -> None:
        self.store.log_event(
            agent="supervisor_agent",
            type_="routing_decision",
            payload={"event_id": event_id, "decision": decision, "alerts": alerts},
            status="routed",
        )
