"""Customer Intelligence Agent.

Narrow and read-mostly: given a transcript (a list of the customer's own
messages, usually reconstructed by the Supervisor from the Sales Agent's
logged turns), produce a structured read on needs/objections/motivations
and log it. Doesn't know where the transcript came from or who consumes
the summary next (Business Strategy Agent, later).
"""

from __future__ import annotations

from app.agents.customer_intelligence.models import CustomerInsights
from app.db import EventStore
from app.llm.client import LLMClient

_SYSTEM_PROMPT = (
    "You are the Customer Intelligence Agent for 9antra's AI Agents Bootcamp sales flow. "
    "Given everything a prospect has said, extract their needs, objections, motivations, "
    "and any satisfaction signals, and score overall purchase intent from 0 to 1."
)


class CustomerIntelligenceAgent:
    def __init__(self, store: EventStore, llm_client: LLMClient):
        self.store = store
        self.llm = llm_client

    def analyze_transcript(self, lead_id: str, transcript: list[str]) -> CustomerInsights:
        joined = "\n".join(transcript)
        insights = self.llm.generate_structured(
            system_prompt=_SYSTEM_PROMPT,
            user_input=joined,
            schema=CustomerInsights,
        )

        self.store.log_event(
            agent="customer_intelligence_agent",
            type_="customer_insights",
            payload={
                "lead_id": lead_id,
                "needs": insights.needs,
                "objections": insights.objections,
                "motivations": insights.motivations,
                "satisfaction_signals": insights.satisfaction_signals,
                "intent_score": insights.intent_score,
            },
            status="completed",
        )
        return insights
