from __future__ import annotations

from pydantic import BaseModel, Field


class CustomerInsights(BaseModel):
    needs: list[str] = Field(default_factory=list)
    objections: list[str] = Field(default_factory=list)
    motivations: list[str] = Field(default_factory=list)
    satisfaction_signals: list[str] = Field(default_factory=list)
    intent_score: float = 0.5  # 0 (cold) .. 1 (ready to buy)
