import re
import unicodedata

class CustomerIntelligenceAgent:
    """
    Explainable multilingual baseline (French/English).
    Handles negation, intensifiers, mixed sentiment, intent, urgency and objections.
    Scores are heuristic indicators, not calibrated probabilities.
    """
    POSITIVE = {
        "positif": [ "intéressé", "interessee", "intéressée", "intéressant", "intéressante", "interesting", "motivé", "motivée",
                    "excellent", "super", "parfait", "utile", "j'aime", "j adore",
                    "enthousiaste", "impatient", "merci", "great", "good", "love", "interested"],
        "negative": ["déçu", "deçu", "déçue", "mauvais", "inquiet", "inquiète",
                     "cher", "chers", "trop cher", "compliqué", "difficile", "pas satisfait", "élevé", "élevée", "élevés", "élevées", "trop cher",
                     "arnaque", "problème", "probleme", "bad", "expensive", "disappointed",
                     "not good", "don't like"]
    }
    NEGATORS = ["ne", "n'", "pas", "plus", "jamais", "aucun", "aucune", "sans", "not", "no", "never", "don't", "doesn't"]
    INTENSIFIERS = ["très", "tres", "vraiment", "extrêmement", "extremement", "tellement", "super", "very", "really", "extremely"]
    PRICE = ["cher", "chère", "frais", "commission", "tarif", "prix", "coût", "cout", "budget", "trop élevé", "trop eleve", "expensive", "afford"]
    TIME = ["temps", "horaire", "disponible", "emploi du temps", "schedule", "délai", "delai", "busy"]
    TRUST = ["confiance", "sécurité", "securite", "fraude", "arnaque", "fiable", "trust", "données personnelles", "donnees personnelles", "privacy", "risque"]
    CAREER = ["emploi", "carrière", "carriere", "travail", "job", "cv", "promotion", "stage", "certification", "reconversion", "métier", "metier"]
    LEARNING = ["apprendre", "formation", "cours", "programme", "compétence", "competence", "python", "linux", "cloud", "devops", "cybersécurité", "cybersecurite", "machine learning", "intelligence artificielle", "data science", "développer", "developper"]
    BUY = ["inscrire", "inscription", "m'inscrire", "réserver", "reserver", "payer", "règlement", "reglement", "confirmer", "commander", "subscribe", "enroll"]
    URGENT = ["urgent", "rapidement", "aujourd'hui", "demain", "dès que possible", "des que possible", "vite", "asap"]

    @staticmethod
    def _norm(s):
        s = (s or "").lower().replace("’", "'")
        s = unicodedata.normalize("NFKD", s)
        return "".join(c for c in s if not unicodedata.combining(c))

    @staticmethod
    def _contains(text, terms):
        
        
        matches = []
        spans = []
        for term in sorted(set(terms), key=lambda x: len(CustomerIntelligenceAgent._norm(x)), reverse=True):
            normalized = CustomerIntelligenceAgent._norm(term)
            pattern = r"(?<!\w)" + re.escape(normalized) + r"(?!\w)"
            found = re.search(pattern, text)
            if not found:
                continue
            span = found.span()
            if any(span[0] < end and span[1] > start for start, end in spans):
                continue
            spans.append(span)
            matches.append(term)
        return matches

    def _sentiment(self, text):
        pos_terms = self._contains(text, self.POSITIVE["positif"])
        neg_terms = self._contains(text, self.POSITIVE["negative"])
        
        pos_effective, neg_effective = [], []
        for term in pos_terms:
            idx = text.find(self._norm(term))
            prefix = text[max(0, idx - 24):idx]
            prefix_tokens = re.findall(r"[a-z']+", prefix)
            (neg_effective if prefix_tokens and prefix_tokens[-1] in [self._norm(x) for x in self.NEGATORS] else pos_effective).append(term)
        for term in neg_terms:
            idx = text.find(self._norm(term))
            prefix = text[max(0, idx - 24):idx]
            prefix_tokens = re.findall(r"[a-z']+", prefix)
            (pos_effective if prefix_tokens and prefix_tokens[-1] in [self._norm(x) for x in self.NEGATORS] else neg_effective).append(term)

        intensifiers = [self._norm(x) for x in self.INTENSIFIERS]
        def polarity_weight(term):
            idx = text.find(self._norm(term))
            prefix_tokens = re.findall(r"[a-z']+", text[max(0, idx - 20):idx])
            return 2 if prefix_tokens and prefix_tokens[-1] in intensifiers else 1
        pos_weight = sum(polarity_weight(t) for t in pos_effective)
        neg_weight = sum(polarity_weight(t) for t in neg_effective)
        if pos_weight and neg_weight:
            label = "Mitigé"
        elif pos_weight > neg_weight:
            label = "Positif"
        elif neg_weight > pos_weight:
            label = "Négatif"
        else:
            label = "Neutre"
        total = pos_weight + neg_weight
        score = 50 if total == 0 else max(5, min(95, round(50 + 25 * (pos_weight-neg_weight) / max(1,total))))
        confidence = 35 if total == 0 else min(92, 52 + 12 * total + (8 if label != "Mitigé" else 0))
        return label, score, confidence, pos_effective, neg_effective

    def run(self, message: str, interest: str = "À déterminer"):
        raw = message or ""
        text = self._norm(raw)
        sentiment, sentiment_score, confidence, pos_hits, neg_hits = self._sentiment(text)

        objections = []
        if self._contains(text, self.PRICE): objections.append("Prix / budget")
        if self._contains(text, self.TIME): objections.append("Disponibilité / temps")
        if self._contains(text, self.TRUST): objections.append("Confiance / sécurité")
        if not objections: objections = ["Aucune objection explicite détectée"]

        motivations = []
        if self._contains(text, self.CAREER): motivations.append("Performance opérationnelle")
        if self._contains(text, self.LEARNING): motivations.append("Optimisation des opérations")
        if not motivations: motivations = ["Motivation à approfondir"]

        buy_signals = self._contains(text, self.BUY)
        question_signals = ["?" in raw, any(x in text for x in ["comment", "combien", "quand", "quel", "quelle", "what", "how", "when"])]
        if buy_signals:
            intent, intent_label, intent_score = "strong_purchase_intent", "Intention d'achat explicite", 92
        elif interest == "Intéressé":
            intent, intent_label, intent_score = "purchase_intent", "Intérêt commercial élevé", 78
        elif any(question_signals):
            intent, intent_label, intent_score = "information_request", "Recherche d'information", 58
        elif interest == "Hésitant":
            intent, intent_label, intent_score = "needs_clarification", "Hésitation / besoin de clarification", 45
        else:
            intent, intent_label, intent_score = "low_interest", "Faible intention déclarée", 20

        emotions = []
        if pos_hits: emotions.append("Intérêt / enthousiasme")
        if neg_hits: emotions.append("Préoccupation / insatisfaction")
        if "Prix / budget" in objections: emotions.append("Préoccupation financière")
        if "Confiance / sécurité" in objections: emotions.append("Besoin de réassurance")
        if not emotions: emotions = ["Émotion non déterminée"]

        urgency = "Élevée" if self._contains(text, self.URGENT) else "Normale"
        evidence = [f"Signal positif : {x}" for x in pos_hits[:3]]
        evidence += [f"Signal négatif : {x}" for x in neg_hits[:3]]
        evidence += [f"Objection : {x}" for x in objections if not x.startswith("Aucune")]
        if not evidence: evidence = ["Message sans marqueur lexical suffisamment explicite."]

        if "Prix / budget" in objections:
            next_action = "Présenter les frais, commissions et modalités de paiement disponibles, sans promettre de remise."
        elif "Disponibilité / temps" in objections:
            next_action = "Préciser les délais de traitement, les modalités de service et le support disponible."
        elif "Confiance / sécurité" in objections:
            next_action = "Présenter les informations vérifiables sur l'organisme, les conditions et la confidentialité."
        elif intent_score >= 78:
            next_action = "Répondre aux dernières questions puis proposer l'étape suivante, sans déclencher de paiement automatiquement."
        else:
            next_action = "Clarifier le type d'opération, le contexte métier et les attentes du client."

        return {
            "agent": "Customer Intelligence Agent",
            "intent": intent, "intent_label": intent_label, "intent_score": intent_score,
            "interest_level": interest, "sentiment": sentiment,
            "sentiment_score": sentiment_score, "sentiment_confidence": confidence,
            "emotions": emotions, "urgency": urgency, "objections": objections,
            "motivations": motivations, "evidence": evidence,
            "next_best_action": next_action,
            "analysis_method": "Explainable lexical baseline with negation and intensity handling",
            "customer_summary": f"Sentiment : {sentiment}. Intention : {intent_label}. Objections : {', '.join(objections)}.",
            "requires_followup": sentiment in ("Négatif", "Mitigé") or intent_score < 70
        }
