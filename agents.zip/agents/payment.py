from typing import Dict, Any, Protocol
import uuid

class PaymentProvider(Protocol):
    def create_payment(self, amount: float, currency: str, customer_reference: str) -> Dict[str, Any]:
        ...

class DemoPaymentProvider:
    """Fournisseur local de démonstration : aucune transaction financière réelle."""
    def __init__(self, outcome="succeeded"):
        if outcome not in ("succeeded", "failed", "pending"):
            raise ValueError("Résultat de démonstration non autorisé.")
        self.outcome = outcome

    def create_payment(self, amount: float, currency: str, customer_reference: str):
        messages = {
            "succeeded": "Paiement fictif confirmé. Aucun compte bancaire n'a été débité.",
            "failed": "Paiement fictif refusé pour la démonstration. Aucun débit réel.",
            "pending": "Paiement fictif en attente de confirmation. Aucun débit réel."
        }
        return {
            "transaction_id": "DEMO-" + uuid.uuid4().hex[:10].upper(),
            "amount": round(float(amount), 2),
            "currency": currency,
            "status": self.outcome,
            "provider": "local_demo",
            "sandbox": True,
            "message": messages[self.outcome]
        }

class PaymentAgent:
    """Le paiement simulé n'est exécuté qu'après autorisation sécurité et validation humaine."""
    def __init__(self, provider=None):
        self.provider = provider or DemoPaymentProvider()

    def run(self, amount, currency, customer_reference, customer_confirmed,
            approved_by_security=False, human_approved=False):
        base = {
            "agent": "Payment Agent",
            "amount": round(float(amount), 2),
            "currency": currency,
            "sandbox": True
        }
        if not customer_confirmed:
            return {**base, "transaction_id": None, "status": "not_started",
                    "provider": "none", "message": "Le client n'a pas confirmé la demande de paiement."}
        if not approved_by_security:
            return {**base, "transaction_id": None, "status": "pending_security",
                    "provider": "none", "message": "En attente de la décision du module Security & Fraud Detection."}
        if not human_approved:
            return {**base, "transaction_id": None, "status": "pending_human_approval",
                    "provider": "none", "message": "Contrôle sécurité autorisé. Validation humaine du propriétaire requise."}
        result = self.provider.create_payment(amount, currency, customer_reference)
        return {**result, "agent": "Payment Agent", "sandbox": True}
