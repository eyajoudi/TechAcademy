class FinancialDataAnalyst:
    def run(self, records):
        total = len(records)
        interested = sum(r.get("interest_level") == "Intéressé" for r in records)
        successful = sum(r.get("payment_status") == "succeeded" for r in records)
        failed = sum(r.get("payment_status") in ("failed", "blocked_by_security") for r in records)
        pending = sum(r.get("payment_status") in (
            "pending", "pending_review", "pending_security",
            "pending_human_approval", "awaiting_owner_approval"
        ) for r in records)
        revenue = sum(float(r.get("amount") or 0) for r in records if r.get("payment_status") == "succeeded")
        objections = {}
        for r in records:
            for objection in r.get("objections", []):
                if objection != "Aucune objection explicite détectée":
                    objections[objection] = objections.get(objection, 0) + 1
        return {
            "agent": "Financial Data Analyst",
            "total_interactions": total,
            "interested_clients": int(interested),
            "successful_payments": int(successful),
            "failed_payments": int(failed),
            "pending_payments": int(pending),
            "simulated_revenue": round(revenue, 2),
            "conversion_rate_percent": round(successful / total * 100, 2) if total else 0,
            "interest_rate_percent": round(interested / total * 100, 2) if total else 0,
            "main_objections": objections
        }
