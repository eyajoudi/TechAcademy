"""Lightweight screening of untrusted customer text; flagged inputs require human review."""
import re
_PATTERNS = {
    "instruction_override": r"ignore (all )?(previous|prior) instructions|forget (all )?(previous|prior) instructions|ignore les instructions|oublie les instructions|ignore toutes les consignes",
    "system_prompt_extraction": r"reveal|show|print|repeat.{0,30}(system prompt|hidden instructions)|affiche.{0,30}(prompt systeme|instructions cachees)|revele.{0,30}(instructions|prompt)",
    "security_bypass": r"bypass|disable|ignore.{0,20}(security|validation|approval|fraud)|contourne.{0,30}(securite|validation|approbation)|desactive.{0,30}(securite|controle)",
    "privilege_escalation": r"act as (an? )?(admin|owner)|give me (admin|owner) access|fais comme si tu etais administrateur|donne moi les droits administrateur",
    "secret_exfiltration": r"(api[_ -]?key|secret|password|mot de passe|cle api).{0,30}(show|reveal|print|send|affiche|envoie|divulgue)",
    "tool_misuse": r"(execute|run|lance|execute).{0,30}(shell|commande systeme|sql|script)\s*(as|avec|en tant que)?\s*(admin|root|owner|proprietaire)"
}
def screen_untrusted_text(text):
    value = str(text or "")[:8000]
    matches = [name for name, pattern in _PATTERNS.items() if re.search(pattern, value, re.I)]
    return {
        "flagged": bool(matches),
        "categories": matches,
        "action": "require_review" if matches else "no_match",
        "note": "Le texte utilisateur est une donnée non fiable ; il ne peut ni modifier les règles système ni autoriser une opération sensible."
    }
