class BusinessStrategyAgent:
    def run(self, customer_insight, financial_kpis, financial_intelligence=None):
        recommendations = []
        objections = customer_insight.get("objections", [])
        if "Prix / budget" in objections:
            recommendations.append("Clarifier la grille tarifaire, les frais de inscription et les commissions.")
        if "Disponibilité / temps" in objections:
            recommendations.append("Réduire les étapes d'intégration et améliorer la disponibilité du support.")
        if "Confiance / sécurité" in objections:
            recommendations.append("Expliquer les contrôles de sécurité, les statuts de inscription et les règles de confidentialité.")
        if financial_kpis.get("conversion_rate_percent", 0) < 30:
            recommendations.append("Analyser les abandons et simplifier le parcours entre intérêt et paiement.")
        if financial_kpis.get("pending_payments", 0) > 0:
            recommendations.append("Mettre en place un suivi informatif des paiements en attente.")
        financial_intelligence = financial_intelligence or {}
        for insight in financial_intelligence.get("insights", [])[:2]:
            if insight not in recommendations:
                recommendations.append(insight)
        if not recommendations:
            recommendations.append("Comparer les performances par formation et profil d’apprenant pour optimiser le catalogue et le parcours d’inscription.")
        return {
            "agent": "Business Strategy Agent",
            "recommendations": recommendations,
            "basis": {
                "objections": objections,
                "conversion_rate_percent": financial_kpis.get("conversion_rate_percent", 0),
                "pending_payments": financial_kpis.get("pending_payments", 0),
                "financial_intelligence": financial_intelligence
            }
        }
