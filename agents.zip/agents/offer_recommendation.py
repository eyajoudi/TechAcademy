"""Explainable training-offer ranking using explicit goals, skills, level and budget signals."""
import re
import unicodedata

class OfferRecommendationAgent:
    DOMAIN_TERMS = {
        "ai_fundamentals": ["intelligence artificielle", "machine learning", "apprentissage automatique", "deep learning", "rag", "retrieval augmented generation", "llm", "generative ai", "ia generative", "agents ia", "prompt engineering"],
        "cybersecurity": ["cybersecurite", "securite informatique", "ethical hacking", "soc", "pentest", "vulnerabilite", "securisation", "reseau", "linux security"],
        "cloud_computing": ["cloud", "aws", "azure", "gcp", "infrastructure cloud", "virtualisation", "deploiement cloud"],
        "devops": ["devops", "docker", "ci/cd", "pipeline", "kubernetes", "integration continue", "deploiement continu", "gitops"],
        "devsecops": ["devsecops", "secure sdlc", "securite logicielle", "pipeline securise", "analyse statique", "sast", "dast"],
        "data_science": ["data science", "business intelligence", "power bi", "pandas", "visualisation", "analyse de donnees", "statistiques"],
        "programming_python": ["python", "programmation", "algorithmique", "developpement logiciel", "poo", "coder", "code"]
    }
    OUTCOME_TERMS = {
        "ai_fundamentals": ["python pour l'ia", "classification", "regression", "modeles de machine learning"],
        "cybersecurity": ["fondamentaux reseau", "linux", "analyse des vulnerabilites", "reponse aux incidents"],
        "cloud_computing": ["iaas", "paas", "deploiement cloud", "reseaux virtuels"],
        "devops": ["git", "linux", "docker", "pipelines ci/cd"],
        "devsecops": ["secure sdlc", "analyse statique", "dependances", "pipelines"],
        "data_science": ["pandas", "nettoyage", "visualisation", "power bi"],
        "programming_python": ["bases python", "algorithmique", "poo"]
    }

    @staticmethod
    def _norm(value):
        value = unicodedata.normalize("NFKD", str(value or "").lower())
        return "".join(c for c in value if not unicodedata.combining(c))

    def _extract_budget(self, text):
        normalized = self._norm(text).replace(",", ".")
        patterns = [
            r"(?:budget|max(?:imum)?|ne pas depasser|jusqu'a)\s*(?:de|:)?\s*(\d+(?:\.\d+)?)\s*(?:tnd|dt|dinars?)?",
            r"(\d+(?:\.\d+)?)\s*(?:tnd|dt|dinars?)"
        ]
        for pattern in patterns:
            match = re.search(pattern, normalized)
            if match:
                return float(match.group(1))
        return None

    def recommend(self, message, products, intelligence=None, budget=None, limit=3):
        text = self._norm(message)
        intelligence = intelligence or {}
        budget = budget if budget is not None else self._extract_budget(text)
        beginner = any(x in text for x in ["debutant", "debutante", "de zero", "aucune experience", "commencer"])
        advanced = any(x in text for x in ["avance", "avancee", "expert", "approfondir", "professionnel"])
        career = any(x in text for x in ["emploi", "stage", "carriere", "cv", "certification", "reconversion", "travail"])
        ranked = []
        for key, product in products.items():
            terms = self.DOMAIN_TERMS.get(key, [])
            matched = [term for term in terms if term in text]
            score = 0
            reasons = []
            if matched:
                # One clear domain match is stronger than many repeated synonyms.
                score += min(58, 38 + 8 * (len(matched) - 1))
                if key == "ai_fundamentals" and any(term in text for term in ["rag", "retrieval augmented generation"]) and "python" in text:
                    score += 20
                    reasons.append("Projet RAG avec Python : correspondance IA générative renforcée")
                reasons.append("Domaine explicitement demandé : " + ", ".join(matched[:3]))
            outcomes = self._norm(" ".join(product.get("outcomes", [])))
            outcome_hits = [term for term in self.OUTCOME_TERMS.get(key, []) if term in text and term in outcomes]
            if outcome_hits:
                score += min(18, 6 * len(outcome_hits))
                reasons.append("Compétences recherchées présentes dans le programme : " + ", ".join(outcome_hits[:3]))
            if beginner:
                audience = self._norm(product.get("audience", ""))
                if any(t in audience for t in ["debutant", "etudiant", "debutants"]):
                    score += 10
                    reasons.append("Public cible compatible avec un niveau débutant")
                elif advanced:
                    score -= 8
            if advanced and any(t in self._norm(product.get("audience", "")) for t in ["avance", "professionnel"]):
                score += 5
                reasons.append("Public cible compatible avec un objectif avancé")
            if budget is not None:
                if float(product.get("price", 0)) <= budget:
                    score += 12
                    reasons.append(f"Tarif dans le budget indiqué ({budget:g} TND)")
                else:
                    score -= 18
                    reasons.append(f"Tarif supérieur au budget indiqué ({budget:g} TND)")
            if career and key in {"cybersecurity", "devops", "devsecops", "data_science", "cloud_computing"}:
                score += 4
                reasons.append("Compétences applicables à un objectif professionnel")
            if "Prix / budget" in intelligence.get("objections", []) and budget is None:
                reasons.append("Budget à préciser avant de confirmer le classement")
            ranked.append({
                "product_key": key, "name": product["name"], "price": product["price"],
                "currency": product["currency"], "score": max(0, min(100, score)),
                "reasons": reasons, "description": product["description"],
                "duration": product.get("duration"), "format": product.get("format"),
                "matched_terms": matched, "budget": budget
            })
        ranked.sort(key=lambda item: (item["score"], -item["price"]), reverse=True)
        relevant = [item for item in ranked if item["score"] >= 30][:limit]
        for rank, item in enumerate(relevant, start=1):
            item["rank"] = rank
            item["confidence_label"] = "Forte" if item["score"] >= 65 else "Modérée"
        needs_clarification = not relevant or relevant[0]["score"] < 50
        questions = []
        if not any(self.DOMAIN_TERMS.get(k) and any(t in text for t in self.DOMAIN_TERMS[k]) for k in products):
            questions.append("Quel domaine souhaitez-vous apprendre : IA, cybersécurité, cloud, DevOps, data ou programmation ?")
        if not (beginner or advanced):
            questions.append("Quel est votre niveau actuel : débutant, intermédiaire ou avancé ?")
        if budget is None:
            questions.append("Avez-vous un budget maximum en TND ?")
        return {
            "agent": "Offer Recommendation Agent",
            "method": "Scoring explicable multi-critères : domaine, compétences, niveau, objectif professionnel et budget",
            "recommendations": relevant,
            "needs_clarification": needs_clarification,
            "clarifying_questions": questions[:2],
            "profile": {"budget_tnd": budget, "level": "débutant" if beginner else "avancé" if advanced else "non précisé", "career_goal": career},
            "disclaimer": "Le score mesure la correspondance avec les critères explicitement exprimés ; ce n'est ni une probabilité de réussite ni une garantie d'emploi."
        }
