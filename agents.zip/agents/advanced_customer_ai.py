"""Hybrid customer-language intelligence: TF-IDF classifier + explainable business signals."""
import re
import unicodedata
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

class AdvancedCustomerAI:
    def __init__(self):
        examples = [
          ("La formation est excellente et très utile", "positive"), ("Je suis satisfait et intéressé par ce cours", "positive"),
          ("Great service, I want to subscribe", "positive"), ("C'est parfait, je veux continuer", "positive"),
          ("La formation est trop chère et compliquée", "negative"), ("Le programme ne correspond pas à mon niveau", "negative"),
          ("Bad experience, I am disappointed", "negative"), ("Le délai est trop long", "negative"),
          ("Quels sont les prérequis et le programme ?", "neutral"), ("Je souhaite avoir plus d'informations", "neutral"),
          ("Can you explain the course content?", "neutral"), ("Je compare plusieurs solutions", "neutral"),
          ("La formation est intéressante mais le prix est élevé", "mixed"), ("Le cours me plaît mais je suis inquiet pour mon niveau", "mixed"),
          ("Good course but the price is expensive", "mixed"), ("C'est utile mais pas assez clair", "mixed")]
        self.vectorizer=TfidfVectorizer(ngram_range=(1,2), strip_accents="unicode", sublinear_tf=True)
        X=self.vectorizer.fit_transform([x[0] for x in examples])
        self.model=LogisticRegression(max_iter=500, class_weight="balanced", random_state=42)
        self.model.fit(X,[x[1] for x in examples])

    def analyze(self, message):
        text=(message or "").strip()
        if not text:
            return {"model":"TF-IDF + LogisticRegression", "label":"neutral", "confidence":0.0,
                    "keywords":[], "topics":[], "method":"hybrid_demo_nlp"}
        vec=self.vectorizer.transform([text])
        probs=self.model.predict_proba(vec)[0]
        idx=int(probs.argmax()); label=str(self.model.classes_[idx])
        words=[w for w in re.findall(r"[A-Za-zÀ-ÿ']+",text.lower()) if len(w)>3]
        topics=[]
        normalized = "".join(c for c in unicodedata.normalize("NFKD", text.lower()) if not unicodedata.combining(c))
        for key,terms in {"pricing":["prix","cher","frais","budget","tarif"],
                          "course_content":["programme","cours","formation","module","contenu"],
                          "career_goals":["emploi","carrière","certification","métier","stage"],
                          "prerequisites":["prérequis","niveau","débutant","avancé"],
                          "schedule":["horaire","emploi du temps","soir","weekend","durée"],
                          "technology":["python","linux","cloud","devops","cybersécurité","machine learning"]}.items():
            if any("".join(c for c in unicodedata.normalize("NFKD", t.lower()) if not unicodedata.combining(c)) in normalized for t in terms): topics.append(key)
        return {"model":"TF-IDF + LogisticRegression", "label":label,
                "confidence":round(float(probs[idx])*100,2), "class_probabilities":{str(c):round(float(p)*100,2) for c,p in zip(self.model.classes_,probs)},
                "keywords":list(dict.fromkeys(words))[:8], "topics":topics,
                "method":"hybrid_demo_nlp", "training_data":"small_synthetic_labeled_corpus",
                "disclaimer":"Classification indicative entraînée sur un petit corpus synthétique ; à valider sur des données représentatives."}
