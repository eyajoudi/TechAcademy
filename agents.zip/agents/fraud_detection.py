"""Explainable ML fraud-risk scoring trained on synthetic demo events only."""
import numpy as np
from sklearn.ensemble import RandomForestClassifier

FEATURES = ["amount", "hour", "transactions_10m", "failed_attempts_24h", "new_device", "geo_distance_km", "merchant_mismatch"]

class FraudDetectionAgent:
    def __init__(self, random_state=42):
        rng = np.random.default_rng(random_state)
        n = 1800
        X = np.column_stack([
            rng.lognormal(4.2, 1.0, n).clip(1, 5000),
            rng.integers(0, 24, n), rng.poisson(1.2, n).clip(0, 12),
            rng.poisson(.25, n).clip(0, 8), rng.binomial(1, .18, n),
            rng.exponential(18, n).clip(0, 500), rng.binomial(1, .08, n)
        ])
        # Synthetic labels encode deliberately transparent demo patterns.
        risk = ((X[:,0] > 900) & (X[:,2] >= 3)) | ((X[:,3] >= 2) & (X[:,4] == 1)) | ((X[:,5] > 120) & (X[:,1] < 5)) | ((X[:,6] == 1) & (X[:,0] > 500))
        risk |= (X[:,2] >= 6) | (X[:,3] >= 4)
        y = risk.astype(int)
        self.model = RandomForestClassifier(n_estimators=120, max_depth=7, min_samples_leaf=4,
                                            class_weight="balanced", random_state=random_state)
        self.model.fit(X, y)
        self.training_note = "RandomForest entraîné sur événements synthétiques générés pour la démonstration."

    def assess(self, transaction):
        values = [
            float(transaction.get("amount", 0)), int(transaction.get("hour", 12)),
            int(transaction.get("transactions_10m", 1)), int(transaction.get("failed_attempts_24h", 0)),
            int(bool(transaction.get("new_device", False))), float(transaction.get("geo_distance_km", 0)),
            int(bool(transaction.get("merchant_mismatch", False)))
        ]
        probability = float(self.model.predict_proba([values])[0][1])
        level = "high" if probability >= .75 else "medium" if probability >= .40 else "low"
        reasons=[]
        if values[0] > 900: reasons.append("Montant élevé par rapport au profil synthétique de référence")
        if values[2] >= 3: reasons.append("Vélocité de transactions élevée")
        if values[3] >= 2: reasons.append("Plusieurs tentatives échouées")
        if values[4]: reasons.append("Nouvel appareil détecté")
        if values[5] > 120: reasons.append("Écart géographique inhabituel")
        if values[6]: reasons.append("Incohérence marchand / opération")
        if not reasons: reasons.append("Aucun indicateur fort dans les variables disponibles")
        importance = sorted(
            [{"feature": name, "importance": round(float(score), 4)}
             for name, score in zip(FEATURES, self.model.feature_importances_)],
            key=lambda item: item["importance"], reverse=True
        )
        return {"agent":"ML Fraud Detection Agent", "risk_score":round(probability*100,2),
                "risk_level":level, "decision":"review" if probability >= .75 else "monitor" if probability >= .40 else "low_risk",
                "signals":reasons, "features":dict(zip(FEATURES, values)),
                "model_feature_importance": importance,
                "model":"RandomForestClassifier", "training_data":"synthetic_demo",
                "disclaimer":"Score expérimental : ne constitue pas une décision bancaire ni une preuve de fraude."}
