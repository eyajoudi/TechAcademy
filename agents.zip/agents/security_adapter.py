"""Local security policy fallback used until the collaborator API is connected.

This is a deterministic demo policy, not a production fraud service.
It consumes the ML assessment and prompt-injection screen already computed
by the main application. High risk/injection => block; medium => review;
low => allow the request to proceed to human Owner approval.
"""
class ExternalSecurityAdapter:
    def review(self, transaction_context):
        ml = transaction_context.get("ml_fraud_assessment", {}) or {}
        injection = ml.get("prompt_injection_screening", {}) or {}
        risk = str(ml.get("risk_level", "unknown")).lower()
        if injection.get("flagged"):
            decision, level = "block", "high"
            reasons = ["Tentative de Prompt Injection détectée par le filtre local."]
        elif risk == "high":
            decision, level = "block", "high"
            reasons = ["Le scoring de risque ML indique un niveau élevé."]
        elif risk == "medium":
            decision, level = "review", "medium"
            reasons = ["Risque moyen : examen manuel du contrôle sécurité requis."]
        elif risk == "low":
            decision, level = "allow", "low"
            reasons = ["Contrôles locaux favorables ; validation Owner encore obligatoire."]
        else:
            decision, level = "review", "unknown"
            reasons = ["Niveau de risque indisponible : examen manuel requis."]
        return {
            "decision": decision,
            "risk_level": level,
            "reasons": reasons,
            "requires_human_approval": True,
            "adapter_status": "local_policy_fallback",
            "policy_source": "local_ml_and_input_guard"
        }
