"""Financial intelligence metrics and explainable decision support."""
from collections import defaultdict

class FinancialIntelligenceAgent:
    def run(self, records):
        rows=list(records or []); total=len(rows)
        success=[r for r in rows if r.get("payment_status")=="succeeded"]
        failed=[r for r in rows if r.get("payment_status") in ("failed","blocked_by_security")]
        pending=[r for r in rows if r.get("payment_status") in ("pending","pending_security","awaiting_owner_approval","pending_human_approval","pending_review")]
        revenue=sum(float(r.get("amount") or 0) for r in success)
        attempted=len(success)+len(failed)
        by_offer=defaultdict(lambda:{"interactions":0,"successful":0,"revenue":0.0})
        for r in rows:
            name=r.get("product_name") or "Non classé"; item=by_offer[name]; item["interactions"]+=1
            if r.get("payment_status")=="succeeded": item["successful"]+=1; item["revenue"]+=float(r.get("amount") or 0)
        offers=[]
        for name,item in by_offer.items():
            item["conversion_percent"]=round(item["successful"]/item["interactions"]*100,2) if item["interactions"] else 0
            item["revenue"]=round(item["revenue"],2); offers.append({"offer":name,**item})
        offers.sort(key=lambda x:x["revenue"],reverse=True)
        insights=[]
        if attempted and len(failed)/attempted >= .20: insights.append("Le taux d'échec est élevé : examiner les causes de refus et le parcours de paiement.")
        if total and len(pending)/total >= .25: insights.append("Un volume important de demandes reste en attente : mesurer les délais de revue et de validation.")
        if offers and offers[0]["revenue"]>0: insights.append(f"L'offre générant le plus de revenu simulé est : {offers[0]['offer']}.")
        if not insights: insights.append("Continuer à collecter des données avant de tirer des conclusions financières robustes.")
        return {"agent":"Financial Intelligence Agent", "interactions":total,
                "successful_transactions":len(success),"failed_transactions":len(failed),"pending_transactions":len(pending),
                "simulated_revenue":round(revenue,2),"average_successful_ticket":round(revenue/len(success),2) if success else 0,
                "average_simulated_revenue_per_interaction":round(revenue/total,2) if total else 0,
                "payment_success_rate_percent":round(len(success)/attempted*100,2) if attempted else 0,
                "failure_rate_percent":round(len(failed)/attempted*100,2) if attempted else 0,
                "pending_rate_percent":round(len(pending)/total*100,2) if total else 0,
                "revenue_by_offer":offers,"insights":insights,
                "disclaimer":"Indicateurs calculés sur les données de démonstration ; revenus simulés, non comptabilité réelle."}
